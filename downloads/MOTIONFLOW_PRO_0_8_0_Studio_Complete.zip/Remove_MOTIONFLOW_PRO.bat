@echo off
set "DEST=%APPDATA%\Adobe\CEP\extensions\MOTIONFLOW_PRO"
if exist "%DEST%" rmdir /s /q "%DEST%"
echo MOTIONFLOW PRO extension files removed.
echo CEP PlayerDebugMode settings were left unchanged because other Adobe extensions may use them.
pause
