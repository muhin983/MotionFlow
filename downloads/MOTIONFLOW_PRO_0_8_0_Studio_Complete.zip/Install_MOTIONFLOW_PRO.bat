@echo off
setlocal EnableExtensions
set "SRC=%~dp0MOTIONFLOW_PRO_CEP"
set "BASE=%APPDATA%\Adobe\CEP\extensions"
set "DEST=%BASE%\MOTIONFLOW_PRO"
set "STAGE=%BASE%\MOTIONFLOW_PRO.__staging"
set "BACKUP=%BASE%\MOTIONFLOW_PRO.__backup"

echo.
echo  ==========================================================
echo   MOTIONFLOW PRO 0.8.0  ^|  SAFE CEP INSTALLER
echo  ==========================================================
echo.
if not exist "%SRC%\CSXS\manifest.xml" (
  echo [ERROR] MOTIONFLOW_PRO_CEP folder was not found.
  echo Extract the complete ZIP first, then run this installer again.
  echo.
  pause
  exit /b 1
)
if not exist "%BASE%" mkdir "%BASE%" >nul 2>&1
if not exist "%BASE%" (
  echo [ERROR] Could not create the Adobe CEP extension folder.
  echo Check your Windows user profile permissions.
  echo.
  pause
  exit /b 1
)

if exist "%STAGE%" rmdir /s /q "%STAGE%"
if exist "%BACKUP%" rmdir /s /q "%BACKUP%"
echo [1/4] Copying new extension to staging folder...
xcopy "%SRC%" "%STAGE%\" /E /I /H /Y >nul
if errorlevel 1 (
  if exist "%STAGE%" rmdir /s /q "%STAGE%"
  echo [ERROR] Staging copy failed. Existing installation was not changed.
  pause
  exit /b 1
)
if not exist "%STAGE%\CSXS\manifest.xml" (
  rmdir /s /q "%STAGE%"
  echo [ERROR] Staged manifest is missing. Existing installation was not changed.
  pause
  exit /b 1
)

echo [2/4] Backing up previous installation...
if exist "%DEST%" move "%DEST%" "%BACKUP%" >nul
if errorlevel 1 (
  rmdir /s /q "%STAGE%"
  echo [ERROR] Could not back up the current installation. Nothing was replaced.
  pause
  exit /b 1
)

echo [3/4] Activating MOTIONFLOW PRO 0.8.0...
move "%STAGE%" "%DEST%" >nul
if errorlevel 1 (
  if exist "%DEST%" rmdir /s /q "%DEST%"
  if exist "%BACKUP%" move "%BACKUP%" "%DEST%" >nul
  echo [ERROR] New installation failed. Previous version was restored where possible.
  pause
  exit /b 1
)
if exist "%BACKUP%" rmdir /s /q "%BACKUP%"

for %%V in (9 10 11 12) do (
  reg add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
)

echo [4/4] Install complete.
echo.
echo NEXT STEPS:
echo  1. Close and restart Adobe After Effects.
echo  2. Open Window ^> Extensions (Legacy) ^> MOTIONFLOW PRO.
echo     If Extensions (Legacy) is absent, CEP may be unavailable in that AE build.
echo  3. Dock the panel wherever you prefer.
echo.
echo Note: this unsigned development build enables CEP debug mode
 echo for the current Windows user. No administrator access is needed.
echo The previous installation was replaced only after staging succeeded.
echo.
pause
endlocal
