@echo off
setlocal
set "EXT=%APPDATA%\Adobe\CEP\extensions\MOTIONFLOW_PRO"
echo.
echo ===== MOTIONFLOW PRO 0.8.0 / AE 2025 CEP CHECK =====
echo Extension folder: %EXT%
if exist "%EXT%\CSXS\manifest.xml" (echo [OK] manifest.xml exists) else (echo [MISSING] manifest.xml)
if exist "%EXT%\client\index.html" (echo [OK] client\index.html exists) else (echo [MISSING] client\index.html)
if exist "%EXT%\host\MotionFlowHost.jsx" (echo [OK] host script exists) else (echo [MISSING] host script)
if exist "%EXT%\client\styles.css" (echo [OK] UI styles exist) else (echo [MISSING] UI styles)
echo.
echo CSXS.12 PlayerDebugMode:
reg query "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode 2>nul
if errorlevel 1 echo [MISSING] CSXS.12 PlayerDebugMode registry value
echo.
echo Manifest dispatch structure:
findstr /C:"<DispatchInfoList>" /C:"<Extension Id=\"com.motionflow.pro.panel\">" /C:"<DispatchInfo>" "%EXT%\CSXS\manifest.xml"
echo.
echo If all files exist and PlayerDebugMode is 1, fully quit After Effects from Task Manager and relaunch it.
echo Then check Window ^> Extensions (Legacy) ^> MOTIONFLOW PRO.
pause
endlocal
