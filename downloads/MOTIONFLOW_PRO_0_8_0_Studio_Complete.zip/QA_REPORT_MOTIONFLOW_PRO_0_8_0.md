# MOTIONFLOW PRO 0.8.0 — QA report

Date: 2026-11-23
Target: Adobe After Effects 2025 (25.x), CEP panel + ExtendScript host.

## Corrected issues from the user checklist

| Checklist item | Correction | Validation status |
|---|---|---|
| Solid and Shape creation fails | Uses native `addSolid` and reacquires vector property groups after every `addProperty` before setting shape/fill values. | Static source review; host runtime still required. |
| HEX and preview not synchronized | Project-fill setting is separate from UI accent; HEX, HTML colour picker, palette swatch and preview synchronize. | Source review; browser runtime still required. |
| Position Z does not work | Automatically enables 3D for 2D layers and reacquires transform properties before writing Z. | Passed mock-host regression. |
| Wiggle / Loop Out expression issue | Existing expression is preserved unless Replace Existing is checked; disabled-but-present expressions are also protected. Loop Out requires 2+ keys and fails clearly otherwise. | Passed mock-host regression. |
| Color Studio swatch changes theme only | Swatch selects project fill; with a selection it applies the fill to supported solids, shape fills and text layers. UI accent is an explicit separate action. | Source review; host runtime still required. |
| Typography preview does not update | Preview renders panel text live; selected text can be read; HEX and color picker synchronize. | Source review; browser runtime still required. |
| Guide/About absent | Added Guide, workspace descriptions, tool hover hints and About/compatibility details. | DOM/source review. |
| Repeated tools/cards | Removed duplicate text motion suggestion cards; animation presets have one central Effects & Presets library. | Source review. |
| Liquid Glass looks opaque | Added selectable Clear/Frosted/Tinted materials, custom tint, masked Gaussian Blur adjustment layers with rounded ADD masks, low-opacity vector surfaces, specular edge, sheen, reflection and animated blur opacity. | Source review and package checks; AE visual runtime test still required. |

## Automated checks run

- `node --check` on client `app.js`: PASS.
- `node --check` on ExtendScript host source: PASS as JavaScript syntax. This does not emulate every AE ExtendScript host API.
- Static UI-action mapping: all 46 generated `data-action` types have a matching `runAction` case (63 action branches total); no duplicate action-tip keys or host method definitions remain.
- Client-to-host bridge mapping: all 30 unique host methods invoked by the client exist.
- Mock host regression: 2D-to-3D Z preserves X/Y and applies Z (PASS); disabled-but-present expressions are protected with Replace off (PASS); explicit Replace applies PingPong (PASS); Loop Out with one key reports a failure (PASS).
- Mock property-group invalidation regression: Solid, Rectangle and Ellipse creation (PASS); vector fill HEX write (PASS); recolouring editable shape fill (PASS); native SolidSource recolouring (PASS).
- XML manifest parse: PASS.
- HTML parse: PASS.
- CSS recursive parse/error scan: PASS (0 parse errors).
- ZIP integrity: PASS after final package creation and `unzip -t` verification.

## Installer and package safety

The installer copies the new extension into a staging directory, validates the staged manifest, then backs up and swaps the previous extension. If staging or activation fails, it attempts to restore the prior installation. The package contains one canonical copy of each mock regression test under `tests/`.

## Host operations and safety

Native operations are wrapped in After Effects undo groups. Transform, anchor and text tools reject or skip animated/expression-driven properties where writing a static value would be destructive. Remove Effects asks for confirmation in the panel. SaaS generation attempts cleanup of partially created layers and restores the previous selection if construction throws.

## Not verified in this environment

After Effects cannot be launched here. Therefore the following still require manual verification in AE 2025: actual Solid/Shape creation, solid-source recolouring, native effects by installed match name, TextDocument changes, Gaussian Blur mask appearance/order, and full CEP panel operation at different panel sizes. Treat this as a checked development release, not a certified host-tested build.

## Recommended in-host test sequence

1. Open an empty test comp and create Solid, Rectangle and Ellipse with a non-default HEX.
2. Select each and use Color Studio swatches; confirm HEX preview and object fill both update, while UI accent stays unchanged.
3. Select a 2D layer, set X/Y/Z and apply; confirm it becomes 3D and values are correct.
4. Add two Position keyframes; apply PingPong. Then disable the expression and retry with Replace off (must protect it); repeat with Replace on (must replace).
5. Try PingPong with one keyframe (must report the 2-key requirement).
6. Open Typography, type a phrase, edit HEX and picker, read a selected text layer, and apply to a static text layer.
7. Put a detailed footage/image layer under the playhead; create Clear, Frosted and Tinted glass cards. Confirm blur is clipped to rounded masks and the layers are editable.
8. Use Ctrl+Z after each operation; inspect the layer stack and confirm no partial orphan layers remain after intentionally triggering a failure if practical.
9. Test at narrow/wide panel dock sizes; scroll each workspace and hover action buttons for help.
