MOTIONFLOW PRO 0.8.0 — STUDIO SUITE / AE 2025

INSTALL
1. Extract this ZIP fully.
2. Run Install_MOTIONFLOW_PRO.bat.
3. Restart Adobe After Effects.
4. Open Window > Extensions (Legacy) > MOTIONFLOW PRO.
5. If the panel does not appear, run CHECK_MOTIONFLOW_PRO_AE2025.bat.

WHAT CHANGED IN 0.8.0
- Fixed Shape/Rectangle/Ellipse creation by reacquiring indexed PropertyGroup references after addProperty().
- Added solid/shape/text recolouring from Color Studio; fill HEX, swatches and colour preview now share one project-fill state, separate from the UI accent.
- Position Z now enables 3D on selected 2D layers and reacquires transform properties before setting Z.
- Wiggle / Loop PingPong / Loop Cycle now protect existing expressions unless Replace Existing is enabled. Disabled-but-present expressions are also protected. Loop Out gives a clear error when the target has fewer than two keyframes.
- Typography now has a live text preview, selected text loading and synchronized HEX / colour picker fields.
- Added About and Guide sections and contextual hover hints.
- Removed overlapping text-motion suggestion cards; the main motion preset library remains the single place to apply layer-wide motion.
- Added Clear / Frosted / Tinted Glass material modes, custom tint, rounded mask geometry, masked Gaussian Blur adjustment layers, translucent vector surfaces, specular rim, top sheen and bottom reflection. Blur layers fade with the surface entrance.
- Added missing host operations for Duplicate, Add Effect, Enable/Disable Effects and Remove Effects.
- Added clearer errors for empty effect stacks and operations that could not update any target.

COLOR WORKFLOW
- Palette swatches set the current project-fill colour and sync the HEX and preview. If supported layers are selected, the swatch is also applied to those layers.
- Apply to Selected Layers applies the current fill to selected solid sources, vector fills and text fills.
- Set as UI Accent only changes panel appearance; it does not recolour project objects.

LIQUID GLASS WORKFLOW
- Put footage, a detailed image, texture or other artwork below where the glass card will be created.
- Open SaaS Motion Lab, choose Clear / Frosted / Tinted, choose a tint HEX, then create a component.
- The host creates editable adjustment layers with rounded ADD masks and native Gaussian Blur, plus editable translucent vector layers and entrance keyframes.
- A flat solid background has no detail to blur, so the blur itself may be subtle. The tint, specular edge and sheen remain visible. This is native masked backdrop blur, not a physical refraction shader.

IMPORTANT
This is a CEP extension for After Effects, not a single JSX file. It uses an ExtendScript host bridge for native AE operations. The extension is targeted at After Effects 2025 (25.x) and compatible CEP-based releases. The extension folder path and ID remain the same, so this installer replaces the previous MOTIONFLOW PRO installation.

LIMITATIONS
- Fonts must already be installed on Windows.
- Native effects availability can vary by After Effects version and installation.
- Flow Graph controls temporal keyframe ease influence; it is not a replacement for the native AE Graph Editor or spatial path editor.
- Masked Gaussian Blur needs visible layers beneath the glass; it cannot blur an empty transparent area.
- The build does not bundle AI generation, offline transcription, maps, rotoscoping or third-party asset search.
- Source-level and mock-host checks passed. Actual host runtime verification in After Effects 2025 remains required; this environment cannot launch AE.
