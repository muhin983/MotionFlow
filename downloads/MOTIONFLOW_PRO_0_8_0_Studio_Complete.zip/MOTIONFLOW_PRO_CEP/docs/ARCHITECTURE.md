# MOTIONFLOW PRO 0.8.0 — Studio Suite

## Architecture
- CEP panel: HTML/CSS/JavaScript interface, persisted UI preferences and local preset storage.
- ExtendScript host bridge: native After Effects layer, keyframe, expression, effect, text, marker and composition operations.
- UI workspaces: Overview, Create, Transform, Animate, Flow Graph, Copy/Paste Lab, Color Studio, Typography, Effects & Presets, My Saved Presets, SaaS Motion Lab, Timeline, Utilities, Guide & About.

## 0.8.0 bug-fix and quality pass
- Shape creation reacquires indexed property-group references after every `addProperty()` call.
- Solid/shape colour inputs, colour picker, HEX field and preview are synchronised through delegated input handling.
- Project fill colour is stored separately from the panel accent; swatches no longer silently recolour the UI.
- Color Studio can apply the selected HEX fill to supported solid sources, vector fills and text documents.
- Position Z switches a static 2D layer to 3D and reacquires transform properties before applying remaining values. Animated or separated Position properties are skipped.
- Wiggle/LoopOut target selection is explicit; LoopOut Cycle/PingPong requires at least two keyframes. Existing expressions are protected unless replacement is enabled.
- Typography includes live preview, load-selected-text, editable document updates and local font suggestions.
- Previously missing host methods for duplicate, add effect, toggle effects and remove effects are implemented.
- Repeated motion-preset entry points were consolidated into Effects & Presets; saved transform snapshots stay in My Saved Presets.
- Guide & About explains every workspace and the tool safety boundaries.
- SaaS Glass uses masked Gaussian Blur adjustment layers, translucent vector fills, rim strokes and a specular highlight. The generator removes its newly-created layers if construction fails.

## Liquid-glass implementation
- Native adjustment layer, Add mask, Gaussian Blur 2 effect and Repeat Edge Pixels; the mask bounds the blur to the component area.
- A separate editable vector surface uses low fill opacity and a brighter rim stroke, with a specular highlight layer.
- Backdrop blur requires visible footage/artwork beneath the component. The blur is an After Effects effect and may increase preview/render cost. This is not a 3D refraction shader or true OS-level glass material.

## Safety and limitations
- Transform paste and entrance presets require supported static properties where relevant.
- Color application skips unsupported layers; it changes solid source colours, vector fill colours and text fills, not arbitrary footage pixels.
- Flow Graph applies temporal ease influence to selected keyframes; it does not edit spatial paths or replace the native Graph Editor.
- Expressions are applied to selected expression-capable properties, falling back to selected-layer Position. Only one expression can be active per property.
- Saved presets and the copy/paste clipboard are stored in CEP localStorage, not embedded in the project.
- Font suggestions require fonts to be installed locally.
- AI generation, offline transcription, map rigs, rotoscoping, third-party asset search and automatic external font installation are not included.

## Validation status
Static JavaScript/ExtendScript syntax, manifest XML, client-to-host method mapping, key UI action references and package integrity are checked in this build. Actual AE 2025 runtime testing must be performed inside After Effects.


## 0.8.0 QA and corrective changes

- Indexed vector PropertyGroups are reacquired after each `addProperty()` call because adding a child can invalidate previously stored references.
- Colour state is split between `motionflow.fill` (project object fill) and `motionflow.accent` (panel UI accent). Palette selection updates the fill HEX/picker preview and applies to supported selected layers when a composition selection exists.
- 3D Position Z edits set `AVLayer.threeDLayer` first, then reacquire all transform references before setting vector values.
- Expression replacement is opt-in and checks both `expressionEnabled` and a non-empty expression string. Loop Out requires two or more keys and reports when no target was updated.
- Text preview is rendered from panel inputs; text fill HEX and colour input synchronize in both directions.
- Glass material uses an adjustment layer with an ADD mask, rounded mask path and native Gaussian Blur, followed by editable low-opacity vector surfaces, specular edges and animated blur opacity. Use footage or detailed artwork beneath the surface for visible backdrop blur.
- About and Guide workspaces explain tool requirements, limitations, selection rules and undo behaviour.
