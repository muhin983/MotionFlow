/* MOTIONFLOW PRO 0.8.0 — After Effects host operations (ExtendScript / ES3) */
(function (root) {
    var MF = {};
    function str(v) { return String(v === undefined || v === null ? "" : v); }
    function esc(s) {
        s = str(s);
        return s.replace(/\\/g, "\\\\").replace(/\"/g, "\\\"").replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\t/g, "\\t");
    }
    function json(v) {
        var t = typeof v, i, a;
        if (v === null || v === undefined) return "null";
        if (t === "string") return "\"" + esc(v) + "\"";
        if (t === "number" || t === "boolean") return String(v);
        if (v instanceof Array) {
            a = []; for (i = 0; i < v.length; i++) a.push(json(v[i]));
            return "[" + a.join(",") + "]";
        }
        a = [];
        for (i in v) if (v.hasOwnProperty(i)) a.push(json(i) + ":" + json(v[i]));
        return "{" + a.join(",") + "}";
    }
    function ok(message, extra) {
        var o = { ok: true, message: message || "Done." }, k;
        if (extra) for (k in extra) if (extra.hasOwnProperty(k)) o[k] = extra[k];
        return json(o);
    }
    function fail(message) { return json({ ok: false, message: str(message) }); }
    function comp() {
        var item = app.project ? app.project.activeItem : null;
        return (item && item instanceof CompItem) ? item : null;
    }
    function selected(c) { try { return c ? c.selectedLayers : []; } catch (e) { return []; } }
    function needComp() { var c = comp(); if (!c) throw new Error("Open or select a composition first."); return c; }
    function needLayers() { var c = needComp(), ls = selected(c); if (!ls || !ls.length) throw new Error("Select at least one layer in the active composition."); return { comp: c, layers: ls }; }
    function prop(layer, matchName) { var tr = layer ? layer.property("ADBE Transform Group") : null; return tr ? tr.property(matchName) : null; }
    function isStatic(p) { try { return !!p && !p.expressionEnabled && p.numKeys === 0; } catch (e) { return false; } }
    function color(hex) {
        hex = str(hex).replace(/^#/, "");
        if (hex.length === 3) hex = hex.charAt(0)+hex.charAt(0)+hex.charAt(1)+hex.charAt(1)+hex.charAt(2)+hex.charAt(2);
        if (!/^[0-9a-fA-F]{6}$/.test(hex)) hex = "17E879";
        return [parseInt(hex.substr(0,2),16)/255, parseInt(hex.substr(2,2),16)/255, parseInt(hex.substr(4,2),16)/255];
    }
    function undo(label, fn) {
        var began = false;
        try { app.beginUndoGroup("MOTIONFLOW PRO — " + label); began = true; var msg = fn(); return ok(msg || (label + " complete.")); }
        catch (e) { return fail(e.toString()); }
        finally { if (began) try { app.endUndoGroup(); } catch (endErr) {} }
    }
    function getRotation(layer) { return prop(layer, "ADBE Rotate Z") || prop(layer, "ADBE Rotation"); }

    MF.getContext = function () {
        try {
            var c = comp(), ls, names = [], i;
            if (!c) return json({ connected: true, hasComp: false, comp: "No active composition", width: 0, height: 0, fps: 0, duration: 0, time: 0, layers: 0, selected: 0, selectedNames: [] });
            ls = selected(c);
            for (i = 0; i < ls.length; i++) names.push(ls[i].name);
            return json({ connected: true, hasComp: true, comp: c.name, width: c.width, height: c.height, fps: c.frameRate, duration: c.duration, time: c.time, layers: c.numLayers, selected: ls.length, selectedNames: names });
        } catch (e) { return json({ connected: true, hasComp: false, error: e.toString() }); }
    };

    MF.create = function (kind, hex) {
        var c;
        try { c = needComp(); } catch (e0) { return fail(e0.toString()); }
        if ((kind === "Solid" || kind === "Rectangle" || kind === "Ellipse") && hex && !/^#?[0-9a-fA-F]{6}$/.test(str(hex))) return fail("Enter a valid 6-digit HEX colour, for example #54A8FF.");
        return undo("Create " + kind, function () {
            var l = null, col = color(hex || "27EE83");
            if (kind === "Null") { l = c.layers.addNull(); l.name = "MF Null"; }
            else if (kind === "3D Null") { l = c.layers.addNull(); l.name = "MF 3D Null"; l.threeDLayer = true; }
            else if (kind === "Solid") { l = c.layers.addSolid(col, "MF Solid", c.width, c.height, c.pixelAspect, c.duration); }
            else if (kind === "Adjustment") { l = c.layers.addSolid([1,1,1], "MF Adjustment", c.width, c.height, c.pixelAspect, c.duration); l.adjustmentLayer = true; }
            else if (kind === "Text") { l = c.layers.addText("Your Text"); l.name = "MF Text"; }
            else if (kind === "Camera") { l = c.layers.addCamera("MF Camera", [c.width/2, c.height/2]); }
            else if (kind === "Light") { l = c.layers.addLight("MF Light", [c.width/2, c.height/2]); }
            else if (kind === "Rectangle" || kind === "Ellipse") {
                l = c.layers.addShape(); l.name = "MF " + kind;
                var rootVec = l.property("ADBE Root Vectors Group");
                rootVec.addProperty("ADBE Vector Group");
                rootVec = l.property("ADBE Root Vectors Group");
                var group = rootVec.property(rootVec.numProperties);
                group.name = kind;
                var contents = group.property("ADBE Vectors Group");
                contents.addProperty(kind === "Ellipse" ? "ADBE Vector Shape - Ellipse" : "ADBE Vector Shape - Rect");
                group = l.property("ADBE Root Vectors Group").property(1);
                contents = group.property("ADBE Vectors Group");
                var shape = contents.property(contents.numProperties);
                if (kind === "Ellipse") shape.property("ADBE Vector Ellipse Size").setValue([420,260]);
                else { shape.property("ADBE Vector Rect Size").setValue([420,260]); shape.property("ADBE Vector Rect Roundness").setValue(24); }
                contents = l.property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group");
                contents.addProperty("ADBE Vector Graphic - Fill");
                contents = l.property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group");
                var fill = contents.property(contents.numProperties);
                fill.property("ADBE Vector Fill Color").setValue(col);
                fill.property("ADBE Vector Fill Opacity").setValue(100);
                var tr = prop(l, "ADBE Position");
                if (tr) tr.setValue([c.width/2,c.height/2]);
            } else throw new Error("Unknown layer type: " + kind);
            for (var i = 1; i <= c.numLayers; i++) c.layer(i).selected = false;
            l.selected = true;
            return kind + " layer created with " + (kind === "Rectangle" || kind === "Ellipse" ? "editable vector fill" : "native After Effects properties") + ".";
        });
    };

        MF.anchor = function (col, row) {
        col = Math.max(0, Math.min(1, Number(col))); row = Math.max(0, Math.min(1, Number(row)));
        var x; try { x = needLayers(); } catch (e) { return fail(e.toString()); }
        return undo("Anchor point", function () {
            var good = 0, skipped = 0, first = "";
            for (var i = 0; i < x.layers.length; i++) {
                var l = x.layers[i];
                try {
                    if (l.threeDLayer || l.parent !== null) throw new Error("3D or parented layers are not supported by this anchor tool.");
                    var a = prop(l,"ADBE Anchor Point"), p = prop(l,"ADBE Position"), s = prop(l,"ADBE Scale"), r = getRotation(l);
                    if (!isStatic(a) || !isStatic(p) || !isStatic(s) || !isStatic(r) || p.dimensionsSeparated) throw new Error("Static 2D transforms required.");
                    var rect = null; try { rect = l.sourceRectAtTime(x.comp.time, false); } catch (e1) {}
                    if (!rect || rect.width === 0 || rect.height === 0) {
                        if (l.source && l.source.width) rect = { left:0, top:0, width:l.source.width, height:l.source.height };
                        else throw new Error("Cannot read layer bounds.");
                    }
                    var oldA = a.value, newA = [rect.left + rect.width*col, rect.top + rect.height*row];
                    var dx = newA[0]-oldA[0], dy = newA[1]-oldA[1], sv=s.value, angle=r.value*Math.PI/180;
                    var sx=dx*sv[0]/100, sy=dy*sv[1]/100;
                    var px=sx*Math.cos(angle)-sy*Math.sin(angle), py=sx*Math.sin(angle)+sy*Math.cos(angle), pv=p.value;
                    a.setValue(newA); p.setValue([pv[0]+px,pv[1]+py]); good++;
                } catch (err) { skipped++; if (!first) first = err.toString(); }
            }
            return "Anchor updated on " + good + " layer(s); skipped " + skipped + (first ? " — " + first : ".");
        });
    };

    MF.align = function (mode) {
        var x; try { x = needLayers(); } catch (e) { return fail(e.toString()); }
        return undo("Align layers", function () {
            var good=0, skipped=0;
            for (var i=0;i<x.layers.length;i++) {
                var l=x.layers[i], p=prop(l,"ADBE Position");
                try {
                    if (!isStatic(p) || p.dimensionsSeparated) throw new Error("Animated or separated Position.");
                    var v=p.value;
                    if(mode==="left")v[0]=0; if(mode==="centerX")v[0]=x.comp.width/2; if(mode==="right")v[0]=x.comp.width;
                    if(mode==="top")v[1]=0; if(mode==="centerY")v[1]=x.comp.height/2; if(mode==="bottom")v[1]=x.comp.height;
                    p.setValue(v); good++;
                } catch(e) { skipped++; }
            }
            return "Aligned " + good + " layer(s); skipped " + skipped + ".";
        });
    };

    MF.getTransform = function () {
        try {
            var x=needLayers(), l=x.layers[0], p=prop(l,"ADBE Position"), s=prop(l,"ADBE Scale"), r=getRotation(l), o=prop(l,"ADBE Opacity");
            return json({ ok:true, name:l.name, x:p.dimensionsSeparated?"":p.value[0], y:p.dimensionsSeparated?"":p.value[1], z:(l.threeDLayer&&!p.dimensionsSeparated)?p.value[2]:"", sx:s.value[0], sy:s.value[1], rotation:r.value, opacity:o.value, threeD:l.threeDLayer });
        } catch(e) { return fail(e.toString()); }
    };
    MF.applyTransform = function (xv,yv,zv,sxv,syv,rv,ov) {
        var x; try { x=needLayers(); } catch(e) { return fail(e.toString()); }
        var vals=[xv,yv,zv,sxv,syv,rv,ov];
        for(var n=0;n<vals.length;n++) if(vals[n]!=="" && vals[n]!==null && isNaN(Number(vals[n]))) return fail("Invalid numeric transform value.");
        if(ov!=="" && (Number(ov)<0 || Number(ov)>100)) return fail("Opacity must be between 0 and 100.");
        return undo("Apply transform",function(){
            var good=0,skip=0,first="",converted=0;
            for(var i=0;i<x.layers.length;i++){
                var l=x.layers[i],changed=false;
                try{
                    var p=prop(l,"ADBE Position"),s=prop(l,"ADBE Scale"),r=getRotation(l),o=prop(l,"ADBE Opacity");
                    if(xv!==""||yv!==""||zv!=="") {
                        if(!isStatic(p)||p.dimensionsSeparated) throw new Error("Position is animated, expression-driven or separated.");
                        if(zv!=="" && !l.threeDLayer) {
                            l.threeDLayer=true; converted++;
                            p=prop(l,"ADBE Position"); s=prop(l,"ADBE Scale"); r=getRotation(l); o=prop(l,"ADBE Opacity");
                        }
                        var pv=p.value;
                        if(xv!=="")pv[0]=Number(xv);
                        if(yv!=="")pv[1]=Number(yv);
                        if(zv!=="") { if(!l.threeDLayer || pv.length<3) throw new Error("Could not enable 3D Position for this layer."); pv[2]=Number(zv); }
                        p.setValue(pv); changed=true;
                    }
                    if(sxv!==""||syv!==""){if(!isStatic(s))throw new Error("Scale is animated or expression-driven.");var sv=s.value;if(sxv!=="")sv[0]=Number(sxv);if(syv!=="")sv[1]=Number(syv);s.setValue(sv);changed=true;}
                    if(rv!==""){if(!isStatic(r))throw new Error("Rotation is animated or expression-driven.");r.setValue(Number(rv));changed=true;}
                    if(ov!==""){if(!isStatic(o))throw new Error("Opacity is animated or expression-driven.");o.setValue(Number(ov));changed=true;}
                    if(changed)good++;else skip++;
                }catch(e){skip++;if(!first)first=l.name+": "+e.toString();}
            }
            return "Updated " + good + " layer(s); auto-enabled 3D on " + converted + "; skipped " + skip + (first ? " — " + first : ".");
        });
    };

        MF.getTextSnapshot = function(){
        try {
            var x=needLayers(),l=x.layers[0],tp=l.property("ADBE Text Properties");
            if(!tp) return json({ok:true,isText:false});
            var dp=tp.property("ADBE Text Document"),td=dp.value,hex="#FFFFFF";
            try { if(td.applyFill){var fc=td.fillColor;hex="#";for(var i=0;i<3;i++){var n=Math.round(fc[i]*255).toString(16).toUpperCase();hex+=(n.length<2?"0":"")+n;}} } catch(e0) {}
            return json({ok:true,isText:true,name:l.name,text:td.text,font:td.font,fontSize:td.fontSize,tracking:td.tracking,fillHex:hex});
        } catch(e) { return fail(e.toString()); }
    };

        MF.applySnapshot = function(xv,yv,zv,sxv,syv,rv,ov,font,size,tracking,hex){
        var x;try{x=needLayers();}catch(e){return fail(e.toString());}
        return undo("Paste MotionFlow style",function(){
            var good=0,skip=0,first="";
            for(var i=0;i<x.layers.length;i++) try {
                var l=x.layers[i],p=prop(l,"ADBE Position"),s=prop(l,"ADBE Scale"),r=getRotation(l),o=prop(l,"ADBE Opacity");
                if(!isStatic(p)||!isStatic(s)||!isStatic(r)||!isStatic(o)||p.dimensionsSeparated)throw new Error("Target transforms are animated or unsupported.");
                var pv=p.value;
                if(xv!==""&&xv!==undefined)pv[0]=Number(xv);
                if(yv!==""&&yv!==undefined)pv[1]=Number(yv);
                if(zv!==""&&zv!==undefined){
                    if(!l.threeDLayer){l.threeDLayer=true;p=prop(l,"ADBE Position");s=prop(l,"ADBE Scale");r=getRotation(l);o=prop(l,"ADBE Opacity");pv=p.value;}
                    if(pv.length<3)throw new Error("Could not enable 3D Position on target layer.");
                    pv[2]=Number(zv);
                }
                p.setValue(pv);
                var sv=s.value;if(sxv!==""&&sxv!==undefined)sv[0]=Number(sxv);if(syv!==""&&syv!==undefined)sv[1]=Number(syv);s.setValue(sv);
                if(rv!==""&&rv!==undefined)r.setValue(Number(rv));if(ov!==""&&ov!==undefined)o.setValue(Number(ov));
                if(font!==""||size!==""||tracking!==""||hex!==""){
                    var tp=l.property("ADBE Text Properties");if(!tp)throw new Error("Text styling can only be pasted to a text layer.");
                    var dp=tp.property("ADBE Text Document");if(!isStatic(dp))throw new Error("Target text document is animated.");
                    var td=dp.value;if(font!=="")td.font=font;if(size!=="")td.fontSize=Number(size);if(tracking!=="")td.tracking=Number(tracking);if(hex!==""){if(!/^#?[0-9a-fA-F]{6}$/.test(str(hex)))throw new Error("Invalid text fill HEX colour.");td.applyFill=true;td.fillColor=color(hex);}dp.setValue(td);
                }
                good++;
            } catch(err) { skip++; if(!first)first=l.name+": "+err.toString(); }
            return "Pasted style to "+good+" layer(s); skipped "+skip+(first?" — "+first:"")+".";
        });
    };

        MF.nudge = function(dx,dy,amount){
        var x;try{x=needLayers();}catch(e){return fail(e.toString());} amount=Number(amount);if(isNaN(amount)||amount<=0)return fail("Nudge amount must be greater than zero.");
        return undo("Nudge layers",function(){var good=0,skip=0;for(var i=0;i<x.layers.length;i++){var l=x.layers[i],p=prop(l,"ADBE Position");try{if(!isStatic(p)||p.dimensionsSeparated||l.threeDLayer)throw new Error("Unsupported transform.");var v=p.value;v[0]+=Number(dx)*amount;v[1]+=Number(dy)*amount;p.setValue(v);good++;}catch(e){skip++;}}return "Nudged " + good + " layer(s); skipped " + skip + ".";});
    };
    MF.flip = function(axis){var x;try{x=needLayers();}catch(e){return fail(e.toString());}return undo("Flip " + axis,function(){var good=0,skip=0;for(var i=0;i<x.layers.length;i++){var p=prop(x.layers[i],"ADBE Scale");try{if(!isStatic(p))throw new Error("Animated scale.");var v=p.value;v[axis==="X"?0:1]*=-1;p.setValue(v);good++;}catch(e){skip++;}}return "Flipped " + good + " layer(s); skipped " + skip + ".";});};
    MF.reset = function(){var x;try{x=needLayers();}catch(e){return fail(e.toString());}return undo("Reset transforms",function(){var good=0,skip=0;for(var i=0;i<x.layers.length;i++){var l=x.layers[i];try{var p=prop(l,"ADBE Position"),s=prop(l,"ADBE Scale"),r=getRotation(l),o=prop(l,"ADBE Opacity");if(!isStatic(p)||!isStatic(s)||!isStatic(r)||!isStatic(o)||p.dimensionsSeparated)throw new Error("Animated or separated transforms.");p.setValue(l.threeDLayer?[x.comp.width/2,x.comp.height/2,0]:[x.comp.width/2,x.comp.height/2]);var sv=s.value;sv[0]=100;sv[1]=100;if(sv.length>2)sv[2]=100;s.setValue(sv);r.setValue(0);o.setValue(100);good++;}catch(e){skip++;}}return "Reset " + good + " layer(s); skipped " + skip + ".";});};

    MF.addKeyframes = function(){var x;try{x=needLayers();}catch(e){return fail(e.toString());}return undo("Add transform keyframes",function(){var good=0;for(var i=0;i<x.layers.length;i++){var l=x.layers[i],tr=l.property("ADBE Transform Group"),names=["ADBE Position","ADBE Scale","ADBE Rotate Z","ADBE Opacity"],count=0;for(var j=0;j<names.length;j++){var p=tr.property(names[j]);if(!p&&names[j]==="ADBE Rotate Z")p=tr.property("ADBE Rotation");try{if(p&&!p.expressionEnabled){p.setValueAtTime(x.comp.time,p.value);count++;}}catch(e){}}if(count)good++;}return "Added transform keyframes on " + good + " layer(s) at the playhead.";});};
    MF.ease = function(linear){linear = (linear === true || String(linear) === "true");var c;try{c=needComp();}catch(e){return fail(e.toString());}return undo(linear?"Linear keyframes":"Easy Ease",function(){var props=c.selectedProperties,changed=0;for(var i=0;i<props.length;i++){var p=props[i];try{if(p.propertyType!==PropertyType.PROPERTY)continue;var keys=p.selectedKeys;if(!keys||!keys.length)continue;for(var k=0;k<keys.length;k++){if(linear)p.setInterpolationTypeAtKey(keys[k],KeyframeInterpolationType.LINEAR,KeyframeInterpolationType.LINEAR);else{var dims=1;try{if(p.value instanceof Array)dims=p.value.length;}catch(e){}var ins=[],outs=[];for(var d=0;d<dims;d++){ins.push(new KeyframeEase(0,66));outs.push(new KeyframeEase(0,66));}p.setInterpolationTypeAtKey(keys[k],KeyframeInterpolationType.BEZIER,KeyframeInterpolationType.BEZIER);p.setTemporalEaseAtKey(keys[k],ins,outs);}changed++;}}catch(e){}}return (linear?"Linear interpolation":"Easy Ease") + " applied to " + changed + " selected keyframe(s).";});};
    MF.textReveal = function(duration){
        var x;try{x=needLayers();}catch(e){return fail(e.toString());}
        duration=Number(duration);if(isNaN(duration)||duration<=0||duration>30)return fail("Duration must be between 0.01 and 30 seconds.");
        return undo("Character text reveal",function(){
            var good=0,skip=0,first="";
            for(var i=0;i<x.layers.length;i++){
                var l=x.layers[i];
                try{
                    var tp=l.property("ADBE Text Properties");if(!tp)throw new Error("Not a text layer.");
                    var animators=tp.property("ADBE Text Animators");
                    animators.addProperty("ADBE Text Animator");
                    tp=l.property("ADBE Text Properties");animators=tp.property("ADBE Text Animators");
                    var anim=animators.property(animators.numProperties);anim.name="MF Character Reveal";
                    var animatorIndex=anim.propertyIndex;
                    var props=anim.property("ADBE Text Animator Properties");
                    props.addProperty("ADBE Text Opacity");
                    anim=l.property("ADBE Text Properties").property("ADBE Text Animators").property(animatorIndex);
                    props=anim.property("ADBE Text Animator Properties");
                    props.property(props.numProperties).setValue(-100);
                    props.addProperty("ADBE Text Position");
                    anim=l.property("ADBE Text Properties").property("ADBE Text Animators").property(animatorIndex);
                    props=anim.property("ADBE Text Animator Properties");
                    props.property(props.numProperties).setValue([0,30]);
                    var selectors=anim.property("ADBE Text Selectors");
                    selectors.addProperty("ADBE Text Selector");
                    anim=l.property("ADBE Text Properties").property("ADBE Text Animators").property(animatorIndex);
                    selectors=anim.property("ADBE Text Selectors");
                    var selector=selectors.property(selectors.numProperties);
                    var offset=selector.property("ADBE Text Percent Offset");
                    offset.setValueAtTime(x.comp.time,-100);offset.setValueAtTime(x.comp.time+duration,100);
                    good++;
                }catch(err){skip++;if(!first)first=l.name+": "+err.toString();}
            }
            return "Character reveal added to "+good+" text layer(s); skipped "+skip+(first?" — "+first:"")+".";
        });
    };

        MF.updateText = function(textValue,size,tracking,hex){
        var x;try{x=needLayers();}catch(e){return fail(e.toString());}
        if(hex!=="" && !/^#?[0-9a-fA-F]{6}$/.test(str(hex)))return fail("Enter a valid 6-digit text fill HEX colour.");
        if(size!=="" && (isNaN(Number(size))||Number(size)<=0))return fail("Font size must be a positive number.");
        if(tracking!=="" && isNaN(Number(tracking)))return fail("Tracking must be a valid number.");
        return undo("Update text",function(){
            var good=0,skip=0,first="";
            for(var i=0;i<x.layers.length;i++)try{
                var tp=x.layers[i].property("ADBE Text Properties");if(!tp)throw new Error("Not a text layer.");
                var p=tp.property("ADBE Text Document");if(!isStatic(p))throw new Error("Text document is animated.");
                var td=p.value;if(textValue!=="")td.text=textValue;if(size!=="")td.fontSize=Number(size);if(tracking!=="")td.tracking=Number(tracking);
                if(hex!==""){td.applyFill=true;td.fillColor=color(hex);}p.setValue(td);good++;
            }catch(err){skip++;if(!first)first=x.layers[i].name+": "+err.toString();}
            return "Updated "+good+" text layer(s); skipped "+skip+(first?" — "+first:"")+".";
        });
    };

        MF.precompose = function(name){var x;try{x=needLayers();}catch(e){return fail(e.toString());}name=String(name||"MF_Precomp");return undo("Pre-compose selected layers",function(){var ids=[];for(var i=0;i<x.layers.length;i++)ids.push(x.layers[i].index);ids.sort(function(a,b){return a-b;});x.comp.layers.precompose(ids,name,true);return "Created precomposition: " + name;});};
    MF.offset = function(frames,stagger){stagger = (stagger === true || String(stagger) === "true");var x;try{x=needLayers();}catch(e){return fail(e.toString());}frames=Number(frames);if(isNaN(frames))return fail("Enter a valid frame count.");return undo(stagger?"Stagger layers":"Offset layers",function(){var delta=frames*x.comp.frameDuration;for(var i=0;i<x.layers.length;i++)try{x.layers[i].startTime+=delta*(stagger?i:1);}catch(e){}return stagger?("Staggered "+x.layers.length+" layers by "+frames+" frame(s)."):("Offset "+x.layers.length+" layers by "+frames+" frame(s).");});};
    MF.trim = function(which){var x;try{x=needLayers();}catch(e){return fail(e.toString());}var t=x.comp.time;return undo("Trim layers",function(){var good=0,skip=0;for(var i=0;i<x.layers.length;i++){try{var l=x.layers[i];if(which==="in"){if(t>=l.outPoint)throw new Error("Playhead after out point.");l.inPoint=t;}else{if(t<=l.inPoint)throw new Error("Playhead before in point.");l.outPoint=t;}good++;}catch(e){skip++;}}return "Trimmed " + good + " layer(s); skipped " + skip + ".";});};
    MF.rename = function(find,repl,prefix,suffix){var x;try{x=needLayers();}catch(e){return fail(e.toString());}return undo("Batch rename",function(){for(var i=0;i<x.layers.length;i++){var n=x.layers[i].name;if(find!=="")n=n.split(find).join(repl);x.layers[i].name=prefix+n+suffix;}return "Renamed " + x.layers.length + " layer(s).";});};
    MF.marker = function(comment){var c;try{c=needComp();}catch(e){return fail(e.toString());}return undo("Add composition marker",function(){c.markerProperty.setValueAtTime(c.time,new MarkerValue(comment||"MOTIONFLOW MARKER"));return "Composition marker added at " + c.time.toFixed(2) + "s.";});};
    MF.duplicate = function(){
        var x;try{x=needLayers();}catch(e){return fail(e.toString());}
        return undo("Duplicate selected layers",function(){
            var originals=x.layers.slice(0),copies=[],good=0,skip=0;
            originals.sort(function(a,b){return a.index-b.index;});
            for(var i=0;i<originals.length;i++)try{copies.push(originals[i].duplicate());good++;}catch(err){skip++;}
            for(var j=1;j<=x.comp.numLayers;j++)try{x.comp.layer(j).selected=false;}catch(e0){}
            for(var k=0;k<copies.length;k++)try{copies[k].selected=true;}catch(e1){}
            if(!good)throw new Error("No selected layers could be duplicated.");
            return "Duplicated "+good+" layer(s); skipped "+skip+". New copies are selected.";
        });
    };
    MF.addEffect = function(matchName,label){
        var x;try{x=needLayers();}catch(e){return fail(e.toString());}
        matchName=str(matchName);label=str(label||matchName);
        if(!matchName)return fail("Choose an effect first.");
        return undo("Add effect — "+label,function(){
            var good=0,skip=0,first="";
            for(var i=0;i<x.layers.length;i++)try{
                var l=x.layers[i],parade=l.property("ADBE Effect Parade");
                if(!parade)throw new Error("This layer does not support effects.");
                parade.addProperty(matchName);good++;
            }catch(err){skip++;if(!first)first=x.layers[i].name+": "+err.toString();}
            if(!good)throw new Error("Could not add "+label+". Check that the effect is available in this After Effects installation."+(first?" "+first:""));
            return "Added "+label+" to "+good+" layer(s); skipped "+skip+".";
        });
    };
    MF.toggleEffects = function(enabled){
        enabled=(enabled===true||String(enabled)==="true");
        var x;try{x=needLayers();}catch(e){return fail(e.toString());}
        return undo(enabled?"Enable effects":"Disable effects",function(){
            var changed=0,skip=0;
            for(var i=0;i<x.layers.length;i++)try{
                var parade=x.layers[i].property("ADBE Effect Parade");if(!parade)continue;
                for(var j=1;j<=parade.numProperties;j++)try{parade.property(j).enabled=enabled;changed++;}catch(e0){skip++;}
            }catch(e1){skip++;}
            if(!changed)throw new Error("No effects were found on the selected layers.");
            return (enabled?"Enabled ":"Disabled ")+changed+" effect(s); skipped "+skip+".";
        });
    };
    MF.removeEffects = function(){
        var x;try{x=needLayers();}catch(e){return fail(e.toString());}
        return undo("Remove all selected-layer effects",function(){
            var removed=0,skip=0;
            for(var i=0;i<x.layers.length;i++)try{
                var l=x.layers[i],parade=l.property("ADBE Effect Parade"),count=parade?parade.numProperties:0;
                for(var j=count;j>=1;j--)try{parade=l.property("ADBE Effect Parade");parade.property(j).remove();removed++;}catch(e0){skip++;}
            }catch(e1){skip++;}
            if(!removed)throw new Error("No removable effects were found on the selected layers.");
            return "Removed "+removed+" effect(s); skipped "+skip+".";
        });
    };
    function expressionTargets(c,targetMode){
        var out=[],props=[];
        if(targetMode!=="position")try{props=c.selectedProperties||[];}catch(e){}
        for(var i=0;i<props.length;i++)try{if(props[i].propertyType===PropertyType.PROPERTY&&props[i].canSetExpression)out.push(props[i]);}catch(e1){}
        if(!out.length){var ls=selected(c);for(var j=0;j<ls.length;j++)try{var p=prop(ls[j],"ADBE Position");if(p&&p.canSetExpression)out.push(p);}catch(e2){}}
        return out;
    }
    MF.expression = function(mode,freq,amp,replaceExisting,targetMode){
        replaceExisting = (replaceExisting === true || String(replaceExisting) === "true");
        var c;try{c=needComp();}catch(e){return fail(e.toString());}
        if(mode==="wiggle"){freq=Number(freq);amp=Number(amp);if(isNaN(freq)||isNaN(amp)||freq<=0||amp<0)return fail("Wiggle frequency must be greater than 0 and amount cannot be negative.");}
        var props=expressionTargets(c,targetMode||"auto");if(!props.length)return fail("Select one or more layers (or expression-capable properties) first.");
        return undo("Apply "+mode+" expression",function(){
            var good=0,skip=0,first="";
            for(var i=0;i<props.length;i++)try{
                var p=props[i];
                if(!p.canSetExpression)throw new Error("This property cannot use expressions.");
                if(mode==="clear") { if(p.expressionEnabled||p.expression!==""){p.expression="";p.expressionEnabled=false;good++;}else skip++; continue; }
                if(mode==="pingpong"||mode==="cycle")if(p.numKeys<2)throw new Error("Loop Out requires at least two keyframes on the target property.");
                if((p.expressionEnabled || p.expression!=="") && !replaceExisting)throw new Error("An expression already exists on this property. Enable Replace Existing Expression or clear it first.");
                var expr=mode==="wiggle"?"wiggle("+Number(freq)+","+Number(amp)+")":mode==="pingpong"?'loopOut("pingpong")':'loopOut("cycle")';
                p.expression=expr;p.expressionEnabled=true;good++;
            }catch(err){skip++;if(!first)first=err.toString();}
            if(!good)throw new Error(first || "No eligible property was changed. Select an expression-capable property; Loop Out requires at least two keyframes.");
            return (mode==="clear"?"Cleared expressions on ":"Applied "+mode+" to ")+good+" property(s); skipped "+skip+(first?" — "+first:"")+".";
        });
    };
    MF.clearExpression = function(targetMode){return MF.expression("clear",0,0,true,targetMode||"auto");};

        function recolorVectorFills(group, rgb){
        var changed=0,count=0;
        try{count=group.numProperties;}catch(e){count=0;}
        for(var i=1;i<=count;i++)try{
            var child=group.property(i),mn="";
            try{mn=child.matchName;}catch(e0){}
            if(mn==="ADBE Vector Fill Color"){child.setValue(rgb);changed++;}
            else if(mn==="ADBE Vector Stroke Color"){ /* preserve deliberate stroke palettes */ }
            else { try{if(child.numProperties>0)changed+=recolorVectorFills(child,rgb);}catch(e1){} }
        }catch(e2){}
        return changed;
    }
    MF.applyColorToSelection = function(hex){
        if(!/^#?[0-9a-fA-F]{6}$/.test(str(hex)))return fail("Enter a valid 6-digit HEX colour.");
        var x;try{x=needLayers();}catch(e){return fail(e.toString());}
        var rgb=color(hex);
        return undo("Apply fill colour",function(){
            var good=0,skip=0,first="",solidCount=0,shapeCount=0,textCount=0;
            for(var i=0;i<x.layers.length;i++)try{
                var l=x.layers[i],done=false;
                var tp=l.property("ADBE Text Properties");
                if(tp){var dp=tp.property("ADBE Text Document");if(!isStatic(dp))throw new Error("Text document is animated.");var td=dp.value;td.applyFill=true;td.fillColor=rgb;dp.setValue(td);textCount++;done=true;}
                if(!done && l.source){try{var src=l.source.mainSource;if(src instanceof SolidSource){src.color=rgb;solidCount++;done=true;}}catch(sourceErr){}}
                if(!done){var vectors=l.property("ADBE Root Vectors Group");if(vectors){var n=recolorVectorFills(vectors,rgb);if(n>0){shapeCount++;done=true;}}}
                if(!done)throw new Error("No editable solid source, shape fill or text fill found.");
                good++;
            }catch(err){skip++;if(!first)first=l.name+": "+err.toString();}
            return "Applied "+str(hex).toUpperCase()+" to "+good+" layer(s) — solids "+solidCount+", shape layers "+shapeCount+", text layers "+textCount+"; skipped "+skip+(first?" — "+first:"")+".";
        });
    };

    // Flow Graph maps the visual curve's time handles to AE temporal-ease influence.
    MF.easeWithInfluence = function(inInfluence, outInfluence) {
        inInfluence = Math.max(1, Math.min(100, Number(inInfluence)));
        outInfluence = Math.max(1, Math.min(100, Number(outInfluence)));
        if (isNaN(inInfluence) || isNaN(outInfluence)) return fail("Flow influence values must be between 1 and 100.");
        var c; try { c = needComp(); } catch (e) { return fail(e.toString()); }
        return undo("Flow Graph easing", function() {
            var props = c.selectedProperties, changed = 0, skipped = 0;
            for (var i=0;i<props.length;i++) {
                var p=props[i];
                try {
                    if (p.propertyType !== PropertyType.PROPERTY) continue;
                    var keys=p.selectedKeys;
                    if (!keys || !keys.length) continue;
                    var dims=1; try { if (p.value instanceof Array) dims=p.value.length; } catch(e0) {}
                    for (var k=0;k<keys.length;k++) {
                        var ins=[], outs=[];
                        for (var d=0;d<dims;d++) { ins.push(new KeyframeEase(0,inInfluence)); outs.push(new KeyframeEase(0,outInfluence)); }
                        p.setInterpolationTypeAtKey(keys[k],KeyframeInterpolationType.BEZIER,KeyframeInterpolationType.BEZIER);
                        p.setTemporalEaseAtKey(keys[k],ins,outs); changed++;
                    }
                } catch(e1) { skipped++; }
            }
            if (!changed) throw new Error("Select one or more keyframes in the After Effects timeline first.");
            return "Flow easing applied to " + changed + " selected keyframe(s); skipped " + skipped + ".";
        });
    };

    MF.setFont = function(fontName,size,tracking,hex) {
        if(hex!=="" && !/^#?[0-9a-fA-F]{6}$/.test(str(hex)))return fail("Enter a valid 6-digit text fill HEX colour.");
        var x; try { x=needLayers(); } catch(e) { return fail(e.toString()); }
        return undo("Typography font and style",function(){
            var good=0,skip=0,first="";
            for(var i=0;i<x.layers.length;i++) try {
                var p=x.layers[i].property("ADBE Text Properties").property("ADBE Text Document");
                if(!isStatic(p)) throw new Error("Text document is animated or not a text layer.");
                var td=p.value;
                if(fontName!=="") td.font=fontName;
                if(size!=="") { if(isNaN(Number(size))||Number(size)<=0) throw new Error("Font size must be positive."); td.fontSize=Number(size); }
                if(tracking!=="") td.tracking=Number(tracking);
                if(hex!=="") { td.applyFill=true; td.fillColor=color(hex); }
                p.setValue(td); good++;
            } catch(err) { skip++; if(!first) first=x.layers[i].name+": "+err.toString(); }
            return "Updated typography on "+good+" text layer(s); skipped "+skip+(first?" — "+first:"")+". Confirm the selected font is installed.";
        });
    };

    MF.applyMotionPreset = function(name,duration) {
        var x; try { x=needLayers(); } catch(e) { return fail(e.toString()); }
        duration=Number(duration); if(isNaN(duration)||duration<=0||duration>30) return fail("Duration must be between 0.01 and 30 seconds.");
        return undo("Motion preset — "+name,function(){
            var t=x.comp.time, good=0, skip=0, first="";
            for(var i=0;i<x.layers.length;i++) try {
                var l=x.layers[i], pp=prop(l,"ADBE Position"), sp=prop(l,"ADBE Scale"), op=prop(l,"ADBE Opacity");
                if(!isStatic(pp)||!isStatic(sp)||!isStatic(op)||pp.dimensionsSeparated) throw new Error("Static, unseparated transforms required.");
                var pos=pp.value, sc=sp.value, opa=op.value, p0=pos.slice(0), s0=sc.slice(0), o0=opa;
                var p1=pos.slice(0), s1=sc.slice(0), o1=opa;
                var key=String(name).toLowerCase();
                if(key==="fade-up"){p0[1]+=70;o0=0;}
                else if(key==="slide-left"){p0[0]-=110;o0=0;}
                else if(key==="slide-right"){p0[0]+=110;o0=0;}
                else if(key==="soft-zoom"){s0[0]*=.82;s0[1]*=.82;o0=0;}
                else if(key==="pop-in"){s0[0]*=.72;s0[1]*=.72;o0=0;}
                else if(key==="overshoot"){s0[0]*=.86;s0[1]*=.86;o0=0;}
                else if(key==="fade-in"){o0=0;}
                else throw new Error("Unknown motion preset.");
                var end=t+duration;
                pp.setValueAtTime(t,p0); pp.setValueAtTime(end,p1);
                if(key==="fade-up"||key==="slide-left"||key==="slide-right") { op.setValueAtTime(t,o0); op.setValueAtTime(end,o1); }
                if(key==="soft-zoom"||key==="pop-in"||key==="overshoot") { sp.setValueAtTime(t,s0); if(key==="overshoot"){ var mid=s1.slice(0);mid[0]*=1.08;mid[1]*=1.08;sp.setValueAtTime(t+duration*.78,mid); } sp.setValueAtTime(end,s1);op.setValueAtTime(t,o0);op.setValueAtTime(end,o1); }
                if(key==="fade-in"){op.setValueAtTime(t,o0);op.setValueAtTime(end,o1);}
                var props=[pp,sp,op];
                for(var q=0;q<props.length;q++) { var pr=props[q]; if(pr.numKeys>=2){ for(var ki=Math.max(1,pr.nearestKeyIndex(t));ki<=pr.numKeys;ki++){var kt=pr.keyTime(ki);if(kt>end+0.0001)break;try{var dim=1;try{if(pr.value instanceof Array)dim=pr.value.length;}catch(e2){}var ei=[],eo=[];for(var di=0;di<dim;di++){ei.push(new KeyframeEase(0,68));eo.push(new KeyframeEase(0,68));}pr.setInterpolationTypeAtKey(ki,KeyframeInterpolationType.BEZIER,KeyframeInterpolationType.BEZIER);pr.setTemporalEaseAtKey(ki,ei,eo);}catch(e3){} } } }
                good++;
            } catch(err) { skip++; if(!first) first=x.layers[i].name+": "+err.toString(); }
            return "Applied "+name+" to "+good+" layer(s); skipped "+skip+(first?" — "+first:"")+".";
        });
    };

    function mfAddRect(c,name,x,y,w,h,hex,opacity,strokeHex,fillOpacity,strokeOpacity) {
        var l=c.layers.addShape();l.name=name;
        var rootVec=l.property("ADBE Root Vectors Group");rootVec.addProperty("ADBE Vector Group");
        rootVec=l.property("ADBE Root Vectors Group");var group=rootVec.property(rootVec.numProperties);group.name="MOTIONFLOW "+name;
        var contents=group.property("ADBE Vectors Group");
        contents.addProperty("ADBE Vector Shape - Rect");
        group=l.property("ADBE Root Vectors Group").property(l.property("ADBE Root Vectors Group").numProperties);
        contents=group.property("ADBE Vectors Group");
        var shape=contents.property(contents.numProperties);shape.property("ADBE Vector Rect Size").setValue([w,h]);shape.property("ADBE Vector Rect Roundness").setValue(18);
        contents=l.property("ADBE Root Vectors Group").property(l.property("ADBE Root Vectors Group").numProperties).property("ADBE Vectors Group");
        contents.addProperty("ADBE Vector Graphic - Fill");
        contents=l.property("ADBE Root Vectors Group").property(l.property("ADBE Root Vectors Group").numProperties).property("ADBE Vectors Group");
        var fill=contents.property(contents.numProperties);fill.property("ADBE Vector Fill Color").setValue(color(hex));
        if(fillOpacity!==undefined)fill.property("ADBE Vector Fill Opacity").setValue(fillOpacity);
        if(strokeHex){
            contents=l.property("ADBE Root Vectors Group").property(l.property("ADBE Root Vectors Group").numProperties).property("ADBE Vectors Group");
            contents.addProperty("ADBE Vector Graphic - Stroke");
            contents=l.property("ADBE Root Vectors Group").property(l.property("ADBE Root Vectors Group").numProperties).property("ADBE Vectors Group");
            var stroke=contents.property(contents.numProperties);stroke.property("ADBE Vector Stroke Color").setValue(color(strokeHex));stroke.property("ADBE Vector Stroke Width").setValue(1.5);
            if(strokeOpacity!==undefined)stroke.property("ADBE Vector Stroke Opacity").setValue(strokeOpacity);
        }
        var tr=prop(l,"ADBE Position");if(tr)tr.setValue([x,y]);
        if(opacity!==undefined){var op=prop(l,"ADBE Opacity");if(op)op.setValue(opacity);}
        return l;
    }
    function mfAddGlassBlur(c,name,x,y,w,h,blurAmount){
        var l=c.layers.addSolid([1,1,1],name,c.width,c.height,c.pixelAspect,c.duration);l.name=name;l.adjustmentLayer=true;
        var masks=l.property("ADBE Mask Parade");masks.addProperty("ADBE Mask Atom");
        masks=l.property("ADBE Mask Parade");var mask=masks.property(masks.numProperties);
        try{mask.maskMode=MaskMode.ADD;}catch(maskModeErr){try{mask.property("ADBE Mask Mode").setValue(MaskMode.ADD);}catch(maskModeErr2){}}
        try{mask.inverted=false;}catch(maskInvertErr){}
        var sh=new Shape(),left=Math.max(0,x-w/2),top=Math.max(0,y-h/2),right=Math.min(c.width,x+w/2),bottom=Math.min(c.height,y+h/2),radius=Math.min(18,(right-left)/6,(bottom-top)/6),k=radius*.5522848;
        sh.vertices=[[left+radius,top],[right-radius,top],[right,top+radius],[right,bottom-radius],[right-radius,bottom],[left+radius,bottom],[left,bottom-radius],[left,top+radius]];
        sh.inTangents=[[-k,0],[0,0],[0,-k],[0,0],[k,0],[0,0],[0,k],[0,0]];
        sh.outTangents=[[0,0],[k,0],[0,0],[0,k],[0,0],[-k,0],[0,0],[0,-k]];sh.closed=true;
        mask.property("ADBE Mask Shape").setValue(sh);
        try{mask.property("ADBE Mask Feather").setValue([7,7]);}catch(e0){}
        try{mask.property("ADBE Mask Opacity").setValue(100);}catch(eMaskOpacity){}
        try{mask.property("ADBE Mask Expansion").setValue(0);}catch(e1){}
        var fxGroup=l.property("ADBE Effect Parade");fxGroup.addProperty("ADBE Gaussian Blur 2");
        fxGroup=l.property("ADBE Effect Parade");var fx=fxGroup.property(fxGroup.numProperties);
        try{fx.property(1).setValue(Number(blurAmount)||26);}catch(e2){throw new Error("Gaussian Blur was added but its blur amount could not be set: "+e2.toString());}
        try{if(fx.numProperties>=3)fx.property(3).setValue(true);}catch(e3){}
        return l;
    }
    function mfAnimateGlassBlur(layer,t,d,delay){
        var op=prop(layer,"ADBE Opacity");if(!op)throw new Error("Glass blur opacity is unavailable.");
        op.setValueAtTime(t+delay,0);op.setValueAtTime(t+delay+d,100);
        try{for(var i=1;i<=op.numKeys;i++){op.setInterpolationTypeAtKey(i,KeyframeInterpolationType.BEZIER,KeyframeInterpolationType.BEZIER);op.setTemporalEaseAtKey(i,[new KeyframeEase(0,68)],[new KeyframeEase(0,68)]);}}catch(e){}
        return true;
    }
    function mfAddGlassRect(c,name,x,y,w,h,tint,accent,fillOpacity,strokeOpacity){
        return mfAddRect(c,name,x,y,w,h,tint,100,"FFFFFF",fillOpacity===undefined?13:fillOpacity,strokeOpacity===undefined?78:strokeOpacity);
    }
    function mfAddGlassHighlight(c,name,x,y,w,accent){
        return mfAddRect(c,name,x,y,w,3,"FFFFFF",100,null,26,0);
    }
    function mfAddText(c,name,text,x,y,size,hex){
        var l=c.layers.addText(text);l.name=name;
        var dp=l.property("ADBE Text Properties").property("ADBE Text Document"),td=dp.value;
        td.fontSize=size;td.applyFill=true;td.fillColor=color(hex);td.applyStroke=false;
        try{td.font="Arial-BoldMT";}catch(e){}
        dp.setValue(td);var p=prop(l,"ADBE Position");if(p)p.setValue([x,y]);return l;
    }
    function mfAnimateEntrance(l,t,d,delay,offset){
        var p=prop(l,"ADBE Position"),o=prop(l,"ADBE Opacity"),v=p.value,from=v.slice(0);from[1]+=offset;
        p.setValueAtTime(t+delay,from);p.setValueAtTime(t+delay+d,v);o.setValueAtTime(t+delay,0);o.setValueAtTime(t+delay+d,100);
        var ei=[],eo=[];for(var z=0;z<(v instanceof Array?v.length:1);z++){ei.push(new KeyframeEase(0,68));eo.push(new KeyframeEase(0,68));}
        for(var q=1;q<=p.numKeys;q++)try{p.setInterpolationTypeAtKey(q,KeyframeInterpolationType.BEZIER,KeyframeInterpolationType.BEZIER);p.setTemporalEaseAtKey(q,ei,eo);}catch(e1){}
        for(var q2=1;q2<=o.numKeys;q2++)try{o.setInterpolationTypeAtKey(q2,KeyframeInterpolationType.BEZIER,KeyframeInterpolationType.BEZIER);o.setTemporalEaseAtKey(q2,[new KeyframeEase(0,68)],[new KeyframeEase(0,68)]);}catch(e2){}
        return true;
    }
    MF.createSaaSComponent = function(template,hex,material,glassHex){
        var c;try{c=needComp();}catch(e){return fail(e.toString());}
        if(hex && !/^#?[0-9a-fA-F]{6}$/.test(str(hex)))return fail("Invalid accent HEX colour.");
        material=String(material||"frosted");if(material!=="clear"&&material!=="frosted"&&material!=="tinted")material="frosted";
        var materialConfig={clear:{blur:22,fill:8,stroke:88},frosted:{blur:46,fill:13,stroke:78},tinted:{blur:62,fill:22,stroke:58}}[material];
        if(glassHex && !/^#?[0-9a-fA-F]{6}$/.test(str(glassHex)))return fail("Enter a valid 6-digit glass tint HEX colour.");
        var accent=color(hex||"27EE83"),accentHex=str(hex||"27EE83").replace(/^#/,""),tintHex=str(glassHex||"B9E8FF").replace(/^#/,""),cx=c.width/2,cy=c.height/2,t=c.time,d=.58,made=[],animated=[],blurCount=0;
        var initialLayerCount=c.numLayers,initialSelection=selected(c).slice(0);
        return undo("SaaS Motion Kit — "+template,function(){
            try {
            var specs=[],bg,blurLayers=[];
            if(template==="glass-card"||template==="dashboard"||template==="browser"){
                specs.push({name:"MF Glass Backdrop Blur",x:cx,y:cy,w:template==="dashboard"?780:620,h:template==="dashboard"?450:360,blur:materialConfig.blur});
                if(template==="dashboard")for(var bi=0;bi<3;bi++)specs.push({name:"MF Metric Backdrop Blur "+(bi+1),x:cx-205+bi*205,y:cy+115,w:178,h:108,blur:Math.max(16,materialConfig.blur-12)});
            } else if(template==="metric") specs.push({name:"MF Metric Backdrop Blur",x:cx,y:cy,w:360,h:210,blur:materialConfig.blur});
            else if(template==="cta") specs.push({name:"MF CTA Backdrop Blur",x:cx,y:cy,w:290,h:88,blur:Math.max(14,materialConfig.blur-18)});
            else if(template==="toggle") specs.push({name:"MF Toggle Backdrop Blur",x:cx,y:cy,w:350,h:100,blur:Math.max(14,materialConfig.blur-18)});
            else throw new Error("Unknown SaaS component template.");
            for(var s=0;s<specs.length;s++){blurLayers.push(mfAddGlassBlur(c,specs[s].name,specs[s].x,specs[s].y,specs[s].w,specs[s].h,specs[s].blur));blurCount++;}
            function add(layer){made.push(layer);animated.push(layer);return layer;}
            if(template==="glass-card"||template==="dashboard"||template==="browser"){
                var glassW=template==="dashboard"?780:620,glassH=template==="dashboard"?450:360;
                add(mfAddGlassRect(c,"MF Liquid Glass Surface",cx,cy,glassW,glassH,tintHex,accentHex,materialConfig.fill,materialConfig.stroke));
                add(mfAddRect(c,"MF Glass Top Sheen",cx,cy-glassH/2+42,glassW-20,72,"FFFFFF",100,null,material==="tinted"?5:9,0));
                add(mfAddRect(c,"MF Glass Bottom Reflection",cx,cy+glassH/2-8,glassW-54,2,"FFFFFF",100,null,material==="tinted"?10:22,0));
                add(mfAddGlassHighlight(c,"MF Glass Specular Highlight",cx,cy-(template==="dashboard"?208:163),template==="dashboard"?720:560,accentHex));
                add(mfAddRect(c,"MF Accent Highlight",cx-255,cy-130,82,4,accentHex,100,null,100,0));
                add(mfAddText(c,"MF Eyebrow","PRODUCT OVERVIEW",cx-245,cy-85,16,accentHex));
                add(mfAddText(c,"MF Heading",template==="dashboard"?"Your workspace":"Designed to move.",cx-245,cy-30,38,"FFFFFF"));
                add(mfAddText(c,"MF Supporting Copy","A clean interface for your next big idea.",cx-245,cy+12,17,"D7E8F2"));
                if(template==="dashboard"){
                    for(var i=0;i<3;i++){
                        var mx=cx-205+i*205;
                        add(mfAddGlassRect(c,"MF Metric Glass Card "+(i+1),mx,cy+115,178,108,tintHex,accentHex,Math.max(8,materialConfig.fill-2),materialConfig.stroke));
                        add(mfAddText(c,"MF Metric Value "+(i+1),["$24.8k","1,284","98.6%"][i],mx-55,cy+103,25,"FFFFFF"));
                        add(mfAddText(c,"MF Metric Label "+(i+1),["Monthly revenue","Active users","Uptime"][i],mx-55,cy+136,12,"D7E8F2"));
                    }
                }
                if(template==="browser"){
                    for(var j=0;j<3;j++)add(mfAddRect(c,"MF Browser Dot "+(j+1),cx-245+j*22,cy-140,9,9,["FF6B6B","FFC85A","48DDE8"][j],100,null,100,0));
                }
            }else if(template==="metric"){
                add(mfAddGlassRect(c,"MF Liquid Metric Card",cx,cy,360,210,tintHex,accentHex,materialConfig.fill,materialConfig.stroke));
                add(mfAddRect(c,"MF Metric Glass Sheen",cx,cy-72,338,42,"FFFFFF",100,null,material==="tinted"?5:9,0));
                add(mfAddGlassHighlight(c,"MF Metric Glass Edge",cx,cy-100,320,accentHex));
                add(mfAddText(c,"MF Metric Value","$48,290",cx-115,cy-8,46,"FFFFFF"));
                add(mfAddText(c,"MF Metric Label","MONTHLY RECURRING REVENUE",cx-115,cy+43,14,accentHex));
                add(mfAddText(c,"MF Metric Delta","↗  +18.4% this month",cx-115,cy+75,15,"B7F6D4"));
            }else if(template==="cta"){
                add(mfAddGlassRect(c,"MF Liquid CTA Surface",cx,cy,290,88,tintHex,accentHex,materialConfig.fill,materialConfig.stroke));
                add(mfAddRect(c,"MF CTA Glass Sheen",cx,cy-32,270,18,"FFFFFF",100,null,material==="tinted"?5:10,0));
                add(mfAddText(c,"MF CTA Label","Get started  →",cx-82,cy+9,23,"FFFFFF"));
            }else if(template==="toggle"){
                add(mfAddGlassRect(c,"MF Liquid Toggle Surface",cx,cy,350,100,tintHex,accentHex,materialConfig.fill,materialConfig.stroke));
                add(mfAddRect(c,"MF Toggle Glass Sheen",cx,cy-36,330,16,"FFFFFF",100,null,material==="tinted"?5:10,0));
                add(mfAddRect(c,"MF Toggle Track",cx+60,cy,118,54,accentHex,100,"FFFFFF",100,72));
                add(mfAddGlassRect(c,"MF Toggle Knob",cx+89,cy,40,40,"F6FCFF","FFFFFF"));
                add(mfAddText(c,"MF Toggle Label","Enable smart workflow",cx-165,cy+9,18,"FFFFFF"));
            }
            var animatedOk=0,animFailed=0;
            for(var bl2=0;bl2<blurLayers.length;bl2++)try{mfAnimateGlassBlur(blurLayers[bl2],t,d,bl2*.04);}catch(blurAnimErr){animFailed++;}
            for(var k=0;k<animated.length;k++)try{if(mfAnimateEntrance(animated[k],t,d,k*.045,22))animatedOk++;}catch(animErr){animFailed++;}
            for(var n=1;n<=c.numLayers;n++)c.layer(n).selected=false;
            for(var bl=0;bl<blurLayers.length;bl++)blurLayers[bl].selected=true;
            for(var m=0;m<made.length;m++)made[m].selected=true;
            return "Created "+made.length+" editable design layers plus "+blurLayers.length+" masked backdrop-blur layer(s) using "+material+" glass material, and "+animatedOk+" animated element(s)"+(animFailed?"; "+animFailed+" animation(s) skipped":"")+". Backdrop blur is visible over footage or artwork beneath the glass.";
            } catch(buildError) {
                while(c.numLayers>initialLayerCount)try{c.layer(1).remove();}catch(cleanupError){break;}
                for(var rs=1;rs<=c.numLayers;rs++)try{c.layer(rs).selected=false;}catch(clearSelectionError){}
                for(var rs2=0;rs2<initialSelection.length;rs2++)try{initialSelection[rs2].selected=true;}catch(restoreSelectionError){}
                throw buildError;
            }
        });
    };

        root.MOTIONFLOW_PRO = MF;
})( $.global );
