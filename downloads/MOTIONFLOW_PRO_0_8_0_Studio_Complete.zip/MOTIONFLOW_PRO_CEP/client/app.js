(function () {
  "use strict";
  var activePage = "home";
  var context = { connected:false, hasComp:false, comp:"After Effects not connected", width:0, height:0, fps:0, duration:0, time:0, layers:0, selected:0, selectedNames:[] };
  var effectNames = {
    glow: ["ADBE Glo2", "Glow"],
    blur: ["ADBE Gaussian Blur 2", "Gaussian Blur"],
    shadow: ["ADBE Drop Shadow", "Drop Shadow"],
    tint: ["ADBE Tint", "Tint"],
    fill: ["ADBE Fill", "Fill"],
    motionTile: ["ADBE Motion Tile", "Motion Tile"],
    turbulent: ["ADBE Turbulent Displace", "Turbulent Displace"],
    sharpen: ["ADBE Sharpen", "Sharpen"],
    mosaic: ["ADBE Mosaic", "Mosaic"],
    noise: ["ADBE Noise", "Noise"],
    posterize: ["ADBE Posterize Time", "Posterize Time"],
    bevel: ["ADBE Bevel Alpha", "Bevel Alpha"]
  };
  var commands = [
    ["Create Null", "CREATE", "createNull"], ["Create 3D Null", "CREATE", "create3DNull"], ["Create Solid", "CREATE", "createSolid"],
    ["Create Adjustment Layer", "CREATE", "createAdjustment"], ["Create Text", "CREATE", "createText"], ["Create Rectangle", "CREATE", "createRectangle"],
    ["Create Ellipse", "CREATE", "createEllipse"], ["Duplicate Layers", "TIMELINE", "duplicate"], ["Pre-compose Layers", "TIMELINE", "precompose"],
    ["Easy Ease Selected Keyframes", "ANIMATE", "ease"], ["Add Transform Keyframes", "ANIMATE", "keyframes"], ["Build Text Reveal", "TYPOGRAPHY", "textReveal"],
    ["Add Glow", "EFFECTS", "glow"], ["Add Gaussian Blur", "EFFECTS", "blur"], ["Flow Graph", "ANIMATE", "pageFlow"], ["Copy Transform", "COPY PASTE", "copyTransform"], ["Paste Transform", "COPY PASTE", "pasteTransform"], ["Open SaaS Motion Lab", "SAAS", "saasGlass"], ["My Saved Presets", "PRESETS", "pageSaved"], ["Color Studio", "COLOR", "pageColors"], ["Apply Fill To Selected Layers", "COLOR", "applySelectionColor"], ["Clear Expression", "ANIMATE", "clearExpression"], ["Open Guide & About", "HELP", "pageHelp"], ["Refresh Composition", "UTILITY", "refresh"]
  ];
  function $(id) { return document.getElementById(id); }
  var actionTips={createNull:"Create a new editable Null controller.",create3DNull:"Create a Null controller with 3D transforms enabled.",createSolid:"Create a full-composition solid using the current fill colour.",createCustomSolid:"Create a full-composition solid using the HEX value above.",createAdjustment:"Create a full-composition adjustment layer.",createText:"Create an editable text layer.",createRectangle:"Create a rounded editable vector rectangle.",createEllipse:"Create an editable vector ellipse.",createCamera:"Create a native camera layer.",createLight:"Create a native light layer.",anchor:"Move the anchor point while preserving visible placement on supported static 2D layers.",align:"Align selected layer positions to the chosen composition edge or centre.",readTransform:"Read transform values from the first selected layer.",applyTransform:"Apply non-empty transform values; entering Z auto-enables 3D after checking static Position.",resetTransform:"Reset supported static transforms to the composition centre.",wiggle:"Apply a wiggle expression to the selected target.",pingpong:"Apply loopOut pingpong to a keyframed property. Requires at least two keys; existing expressions are protected unless Replace is checked.",loop:"Apply loopOut cycle to a keyframed property. Requires at least two keys; existing expressions are protected unless Replace is checked.",clearExpression:"Remove the active expression from the selected target.",updateText:"Write the current text, size, tracking and fill into selected static text layers.",readText:"Load the first selected text layer into the editor and live preview.",textReveal:"Add an editable character reveal animator to selected text layers.",applySelectionColor:"Apply the selected fill colour to supported selected layers.",setAccentFromFill:"Use the selected project fill as the panel UI accent only; it does not recolour the project.",useColor:"Select a project fill swatch. HEX and preview update; with supported layers selected, the colour is applied to them. Does not change the panel accent.",usePalette:"Load a palette and set its primary colour as the current project fill. With supported layers selected, it is applied to them.",applyCustomPalette:"Save this HEX as the current layer fill colour.",createSaaS:"Generate editable SaaS layers with a selected glass material and masked Gaussian backdrop blur.",applyFlow:"Apply the graph's in/out influence to selected timeline keyframes.",copyTransform:"Copy a selected layer's static transform and supported text styling.",pasteTransform:"Paste the stored transform and supported text styling.",savePreset:"Store the selected layer transform locally for reuse.",applySaved:"Apply a stored transform snapshot to selected layers.",deleteSaved:"Remove this saved preset from local storage.",effect:"Add this native After Effects effect to selected layers.",motionPreset:"Build an editable entrance animation using real keyframes.",duplicate:"Duplicate selected layers.",precompose:"Move selected layers into a new composition.",rename:"Rename selected layers with find/replace, prefix and suffix.",marker:"Add a composition marker at the current playhead.",refresh:"Refresh active composition and selection details.",ease:"Apply Easy Ease to selected keyframes in the timeline.",linear:"Set selected keyframes to linear interpolation.",keyframes:"Add transform keyframes at the current playhead.",flowPreset:"Load a curve preset into the Flow Graph editor.",flowHandles:"Drag the graph handles to shape temporal easing influence.",setFont:"Preview this font and apply it to selected text layers.",clearClipboard:"Clear the MotionFlow local style clipboard.",offset:"Shift selected layer start times by the requested number of frames.",stagger:"Stagger selected layer start times by the requested frame interval.",trimIn:"Set selected layers' in-points to the current playhead.",trimOut:"Set selected layers' out-points to the current playhead.",nudge:"Nudge selected 2D layers by the chosen amount.",flipX:"Flip selected layers horizontally by changing Scale X.",flipY:"Flip selected layers vertically by changing Scale Y.",enableEffects:"Enable all effects on selected layers.",disableEffects:"Temporarily disable all effects on selected layers.",removeEffects:"Remove all effects from selected layers. This can be undone."};
  var DEFAULT_ACCENT = "#27EE83";
  function normaliseHex(hex) {
    var h = String(hex || "").replace(/[^0-9a-f]/ig, "").toUpperCase();
    if (h.length === 3) h = h.replace(/(.)/g, "$1$1");
    return h.length === 6 ? "#" + h : DEFAULT_ACCENT;
  }
  function hexRgb(hex) {
    var h = normaliseHex(hex).slice(1);
    return [parseInt(h.slice(0,2),16), parseInt(h.slice(2,4),16), parseInt(h.slice(4,6),16)];
  }
  function rgbHex(rgb) {
    return "#" + rgb.map(function(v){ var h=Math.max(0,Math.min(255,Math.round(v))).toString(16).toUpperCase(); return h.length<2?"0"+h:h; }).join("");
  }
  function applyAccent(hex, persist) {
    var value = normaliseHex(hex), rgb = hexRgb(value), darker = rgb.map(function(v){return v*0.72;}), brightness = (rgb[0]*299 + rgb[1]*587 + rgb[2]*114)/1000;
    var root = document.documentElement;
    root.style.setProperty("--green", value);
    root.style.setProperty("--green2", rgbHex(darker));
    root.style.setProperty("--green-rgb", rgb.join(","));
    root.style.setProperty("--green-dim", "rgba("+rgb.join(",")+",.12)");
    root.style.setProperty("--green-contrast", brightness > 158 ? "#06110A" : "#F4F8F5");
    if ($("accentPicker")) $("accentPicker").value = value.toLowerCase();
    if ($("themeHex")) $("themeHex").textContent = value;
    if ($("themeCurrentDot")) $("themeCurrentDot").style.background = value;
    Array.prototype.forEach.call(document.querySelectorAll(".theme-swatch"), function (b) {
      b.classList.toggle("active", normaliseHex(b.getAttribute("data-accent")) === value);
    });
    if (persist !== false) { try { window.localStorage.setItem("motionflow.accent", value); } catch (e) {} }
    return value;
  }
  function currentAccentHex() { return normaliseHex(getComputedStyle(document.documentElement).getPropertyValue("--green").trim()); }
  var DEFAULT_FILL = "#54A8FF";
  var previewFont = "Inter";
  function currentFillHex(){ try{return normaliseHex(window.localStorage.getItem("motionflow.fill")||DEFAULT_FILL);}catch(e){return DEFAULT_FILL;} }
  function setCurrentFill(hex,persist){ var value=normaliseHex(hex);if(persist!==false)try{window.localStorage.setItem("motionflow.fill",value);}catch(e){}return value; }
  function syncFillFields(hex){
    var value=normaliseHex(hex),lower=value.toLowerCase();
    ["solidHex","paletteHex"].forEach(function(id){var el=$(id);if(el)el.value=value;});
    ["solidColor","palettePicker"].forEach(function(id){var el=$(id);if(el)el.value=lower;});
    Array.prototype.forEach.call(document.querySelectorAll(".palette-swatch"),function(b){b.classList.toggle("selected",normaliseHex(b.getAttribute("data-color"))===value);});
  }
  function updateTextPreview(){
    var sample=$("textPreviewText");if(!sample)return;
    var content=$("textContent")?$("textContent").value:"",size=$("textSize")?Number($("textSize").value):48,tracking=$("textTracking")?Number($("textTracking").value):0,fill=$("textFill")?normaliseHex($("textFill").value):"#FFFFFF";
    if(!content)content="MAKE EVERY WORD MOVE.";
    if(!isFinite(size)||size<=0)size=48;if(!isFinite(tracking))tracking=0;
    sample.textContent=content;sample.style.fontFamily='"'+previewFont+'", Inter, "Segoe UI", Arial, sans-serif';sample.style.fontSize=Math.max(12,Math.min(68,size*.48))+"px";sample.style.letterSpacing=Math.max(-2,Math.min(18,tracking*.12))+"px";sample.style.color=fill;
    var meta=$("textPreviewMeta");if(meta)meta.textContent=previewFont+"  ·  "+size+" PX  ·  "+fill;
  }
  function readSelectedText(){
    invoke("getTextSnapshot",[],function(data){if(!data||!data.ok||!data.isText){toast("Select a text layer to load its document.",true);return;}
      if($("textContent"))$("textContent").value=data.text||"";if($("textSize"))$("textSize").value=data.fontSize||"";if($("textTracking"))$("textTracking").value=data.tracking||"";if($("textFill"))$("textFill").value=data.fillHex||"#FFFFFF";
      if($("textFillPicker"))$("textFillPicker").value=(data.fillHex||"#FFFFFF").toLowerCase();previewFont=(data.font||"Inter").replace(/[-_](Regular|Medium|Bold|SemiBold|Light)$/i,"");updateTextPreview();toast("Loaded text document from "+(data.name||"selected layer")+".");
    });
  }
  function initAppearance() {
    var stored = DEFAULT_ACCENT;
    try { stored = window.localStorage.getItem("motionflow.accent") || DEFAULT_ACCENT; } catch (e) {}
    applyAccent(stored, false);
    var btn = $("themeBtn"), pop = $("themePopover");
    if (btn && pop) {
      btn.addEventListener("click", function (e) {
        e.stopPropagation(); var open = !pop.classList.contains("open"); pop.classList.toggle("open", open); pop.setAttribute("aria-hidden", open ? "false" : "true"); btn.setAttribute("aria-expanded", open ? "true" : "false");
      });
      if ($("themeClose")) $("themeClose").addEventListener("click", function(){ pop.classList.remove("open"); pop.setAttribute("aria-hidden","true"); btn.setAttribute("aria-expanded","false"); });
      Array.prototype.forEach.call(document.querySelectorAll(".theme-swatch"), function (swatch) {
        swatch.addEventListener("click", function(){ var selected=applyAccent(swatch.getAttribute("data-accent"),true); toast("Accent colour updated to " + selected + "."); });
      });
      if ($("accentPicker")) { $("accentPicker").addEventListener("input", function(){ applyAccent(this.value,true); }); $("accentPicker").addEventListener("change", function(){ toast("Custom accent applied: " + applyAccent(this.value,true) + "."); }); }
      if ($("accentReset")) $("accentReset").addEventListener("click", function(){ applyAccent(DEFAULT_ACCENT,true); toast("Accent colour reset to Emerald."); });
      document.addEventListener("click", function(e){ if(!e.target.closest || !e.target.closest(".theme-control")){ pop.classList.remove("open"); pop.setAttribute("aria-hidden","true"); btn.setAttribute("aria-expanded","false"); } });
      document.addEventListener("keydown", function(e){ if(e.key === "Escape"){ pop.classList.remove("open"); pop.setAttribute("aria-hidden","true"); btn.setAttribute("aria-expanded","false"); } });
    }
  }
  function escapeHtml(value) { return String(value === undefined || value === null ? "" : value).replace(/[&<>"']/g, function (c) { return { "&":"&amp;", "<":"&lt;", ">":"&gt;", "\"":"&quot;", "'":"&#39;" }[c]; }); }
  function toast(message, isError) {
    var stack = $("toastStack"), node = document.createElement("div");
    node.className = "toast" + (isError ? " error" : ""); node.textContent = message;
    stack.appendChild(node); window.setTimeout(function () { if (node.parentNode) node.parentNode.removeChild(node); }, 3300);
  }
  function setStatus(message, isError) {
    $("statusText").textContent = message;
    $("statusLed").className = "status-led" + (isError ? " error" : "");
  }
  function bridgeAvailable() { return !!(window.__adobe_cep__ && typeof window.__adobe_cep__.evalScript === "function"); }
  function quoteArg(v) { return "'" + String(v === undefined || v === null ? "" : v).replace(/\\/g,"\\\\").replace(/'/g,"\\'").replace(/\r/g,"\\r").replace(/\n/g,"\\n") + "'"; }
  function invoke(method, args, callback, silent) {
    if (!bridgeAvailable()) {
      setStatus("After Effects host bridge unavailable", true);
      toast("Open MOTIONFLOW PRO inside After Effects to run native tools.", true);
      return;
    }
    var script = "(function(){if(!$.global.MOTIONFLOW_PRO || !$.global.MOTIONFLOW_PRO." + method + ") return '{\"ok\":false,\"message\":\"Host module not loaded. Restart After Effects and reopen the panel.\"}'; return $.global.MOTIONFLOW_PRO." + method + "(" + (args || []).map(quoteArg).join(",") + ");})()";
    setStatus("Running " + method + "…", false);
    window.__adobe_cep__.evalScript(script, function (result) {
      var data;
      try { data = JSON.parse(result); } catch (e) { data = { ok: result !== "EvalScript error.", message: String(result || "No response from After Effects.") }; }
      if (data && data.ok) {
        setStatus(data.message || "Operation complete", false);
        if (!silent) toast(data.message || "Operation complete.", false);
        refreshContext();
        if (callback) callback(data);
      } else {
        var msg = data && data.message ? data.message : "The operation could not be completed.";
        setStatus(msg, true); if (!silent) toast(msg, true);
        if (callback) callback(data || {ok:false,message:msg});
      }
    });
  }
  function refreshContext() {
    if (!bridgeAvailable()) {
      $("hostPill").classList.add("disconnected"); $("hostState").textContent = "NOT IN AE";
      $("compName").textContent = "Open this panel in After Effects"; $("compSize").textContent = "—";
      return;
    }
    window.__adobe_cep__.evalScript("$.global.MOTIONFLOW_PRO ? $.global.MOTIONFLOW_PRO.getContext() : '{\"connected\":false}'", function (result) {
      try { context = JSON.parse(result); } catch (e) { context.connected = false; }
      if (context.connected) {
        $("hostPill").classList.remove("disconnected"); $("hostState").textContent = "AE CONNECTED";
      } else { $("hostPill").classList.add("disconnected"); $("hostState").textContent = "BRIDGE ERROR"; }
      $("compName").textContent = context.hasComp ? context.comp : "No active composition";
      $("compSize").textContent = context.hasComp ? (context.width + "×" + context.height) : "—";
      $("selectionStatus").textContent = (context.selected || 0) + " SELECTED";
      updateHomeStats();
    });
  }
  function updateHomeStats() {
    var nodes = { compStat: context.hasComp ? context.comp : "—", sizeStat: context.hasComp ? context.width + " × " + context.height : "No comp", layerStat: context.hasComp ? context.layers : "—", selectedStat: context.hasComp ? context.selected : "—", fpsStat: context.hasComp ? Number(context.fps).toFixed(2) + " FPS" : "—" };
    Object.keys(nodes).forEach(function (id) { var el = $(id); if (el) el.textContent = nodes[id]; });
  }
  function pageIntro(kicker, title, desc, tag) {
    return '<div class="page-intro"><div><div class="page-kicker">' + kicker + '</div><h2>' + title + '</h2><p>' + desc + '</p></div>' + (tag ? '<span class="pill">' + tag + '</span>' : '') + '</div>';
  }
  function section(title, desc, body, tag) {
    return '<div class="section-head"><div><h3>' + title + '</h3><p>' + (desc || "") + '</p></div>' + (tag ? '<span class="section-tag">' + tag + '</span>' : '') + '</div>' + body;
  }
  function toolCard(icon, title, desc, action, label, style) {
    return '<div class="tool-card"><div class="card-top"><span class="tool-icon">' + icon + '</span><span class="section-tag">NATIVE TOOL</span></div><h4>' + title + '</h4><p class="desc">' + desc + '</p><button class="btn ' + (style || "soft") + ' full" data-action="' + action + '">' + (label || "RUN TOOL") + '</button></div>';
  }
  function layerCard(icon, title, desc, action, label) {
    return '<div class="layer-card"><span class="tool-icon">' + icon + '</span><div class="layer-info"><strong>' + title + '</strong><small>' + desc + '</small></div><button class="btn small soft" data-action="' + action + '">' + (label || "ADD") + '</button></div>';
  }
  function renderHome() {
    var orbit = '<div class="hero-orbit"><svg viewBox="0 0 150 110" fill="none"><path d="M8 87C34 20 96 9 139 37" stroke="var(--green)" stroke-opacity=".65" stroke-width="1.4"/><path d="M15 103C45 48 99 27 147 54" stroke="var(--green)" stroke-opacity=".28" stroke-width="1"/><circle cx="76" cy="54" r="27" stroke="var(--green)" stroke-opacity=".45"/><circle cx="76" cy="54" r="14" fill="var(--green)" fill-opacity=".14" stroke="var(--green)"/><path d="M69 54L76 47L83 54L76 61Z" fill="var(--green)"/><circle cx="132" cy="27" r="3" fill="var(--green)"/><circle cx="21" cy="87" r="2" fill="var(--green)"/></svg></div>';
    var html = '<div class="hero"><div class="hero-kicker">YOUR MOTION DESIGN WORKSPACE</div><h2>Make motion<br>happen faster.</h2><p>A focused toolkit for building, animating and organising After Effects projects — without breaking your flow.</p><div class="hero-actions"><button class="btn primary" data-page="create">＋ Create layers</button><button class="btn" data-page="animate">Explore animation tools <span>↗</span></button></div>' + orbit + '</div>';
    html += section("Project snapshot", "Live information from your active composition.", '<div class="stats-grid"><div class="stat-card"><div class="stat-top"><span>COMPOSITION</span><span class="stat-icon">▣</span></div><div class="stat-value" id="compStat">—</div><div class="stat-caption" id="sizeStat">No comp</div></div><div class="stat-card"><div class="stat-top"><span>LAYERS</span><span class="stat-icon">▱</span></div><div class="stat-value" id="layerStat">—</div><div class="stat-caption">In active composition</div></div><div class="stat-card"><div class="stat-top"><span>SELECTION</span><span class="stat-icon">◎</span></div><div class="stat-value" id="selectedStat">—</div><div class="stat-caption" id="fpsStat">—</div></div></div>');
    html += section("Quick create", "One click to add editable native layers.", '<div class="quick-grid"><button class="quick-tile" data-action="createNull"><span class="tile-icon">＋</span><span><strong>Null Object</strong><small>Controller layer</small></span></button><button class="quick-tile" data-action="createSolid"><span class="tile-icon">▰</span><span><strong>Solid Layer</strong><small>Colour surface</small></span></button><button class="quick-tile" data-action="createText"><span class="tile-icon">T</span><span><strong>Text Layer</strong><small>Editable type</small></span></button><button class="quick-tile" data-action="createRectangle"><span class="tile-icon">▢</span><span><strong>Shape Layer</strong><small>Rectangle shape</small></span></button></div>');
    html += section("Popular workflows", "Go straight to the tools you use most.", '<div class="card-grid">' + toolCard("⌁","Easy Ease","Apply smooth temporal easing to selected timeline keyframes.","ease","APPLY EASY EASE") + toolCard("◈","Anchor control","Set precise nine-point anchor positions on supported 2D layers.","pageTransform","OPEN ANCHOR TOOLS") + toolCard("▤","Layer organiser","Duplicate, pre-compose, rename and stagger selected layers.","pageTimeline","ORGANISE LAYERS") + toolCard("✳","Native effects","Add common After Effects effects to selected layers.","pageEffects","BROWSE EFFECTS") + '</div>');
    html += '<div class="warning-note" style="margin-top:12px">MOTIONFLOW only runs operations in the active After Effects project. Animated, expression-driven or unsupported properties are skipped where a static edit would be unsafe.</div>';
    return html;
  }
  function renderCreate() {
    var themeColour = currentFillHex();
    var html = pageIntro("BUILD / 01", "Create layers", "Build editable native After Effects layers with a consistent naming workflow.", "9 LAYER TYPES");
    html += section("Essentials", "The building blocks of a motion design composition.", '<div class="card-grid">' + layerCard("＋","Null Object","2D controller layer","createNull") + layerCard("◈","3D Null","3D controller layer","create3DNull") + layerCard("▰","Solid Layer","Full comp-sized colour solid","createSolid") + layerCard("▱","Adjustment Layer","Full comp-sized adjustment layer","createAdjustment") + layerCard("T","Text Layer","Editable point text","createText") + layerCard("▢","Rectangle Shape","Editable vector rectangle with fill","createRectangle") + layerCard("◯","Ellipse Shape","Editable vector ellipse with fill","createEllipse") + layerCard("◉","Camera","Create a native camera layer","createCamera") + layerCard("☼","Light","Create a native light layer","createLight") + '</div>');
    html += section("Solid & shape colour", "Choose the colour used for newly created solids and shape fills.", '<div class="tool-card"><div class="field-row"><div class="field"><label>HEX COLOUR</label><input class="input" id="solidHex" value="' + themeColour + '" maxlength="7"></div><div class="field" style="max-width:54px"><label>PREVIEW</label><input type="color" id="solidColor" value="' + themeColour.toLowerCase() + '" class="input" style="padding:3px"></div><button class="btn primary" data-action="createCustomSolid">CREATE SOLID</button></div><p class="muted-note">The chosen colour is used by the Solid, Rectangle and Ellipse creation tools.</p></div>');
    return html;
  }
  function renderTransform() {
    var html = pageIntro("CONTROL / 02", "Transform & anchor", "Precisely position, scale and align selected layers. Entering a Z value automatically enables 3D while preserving X and Y.", "SELECTION AWARE");
    html += '<div class="two-col"><div class="tool-card"><div class="card-top"><h4>Nine-point anchor</h4><span class="pill">2D STATIC</span></div><p class="desc">Move the anchor point while preserving the layer’s visible position.</p><div class="anchor-pad">' + [['TL',0,0],['TC',.5,0],['TR',1,0],['ML',0,.5],['C',.5,.5],['MR',1,.5],['BL',0,1],['BC',.5,1],['BR',1,1]].map(function (a) { return '<button class="' + (a[0]==="C"?"center":"") + '" data-action="anchor" data-x="' + a[1] + '" data-y="' + a[2] + '">' + a[0] + '</button>'; }).join('') + '</div></div><div class="tool-card"><div class="card-top"><h4>Align to composition</h4><span class="pill">POSITION</span></div><p class="desc">Align selected layer positions to the comp edges or centre.</p><div class="align-grid"><button class="btn" data-action="align" data-mode="left">LEFT</button><button class="btn" data-action="align" data-mode="centerX">CENTER X</button><button class="btn" data-action="align" data-mode="right">RIGHT</button><button class="btn" data-action="align" data-mode="top">TOP</button><button class="btn" data-action="align" data-mode="centerY">CENTER Y</button><button class="btn" data-action="align" data-mode="bottom">BOTTOM</button></div></div></div>';
    html += section("Transform inspector", "Read the first selected layer, then apply entered values to all selected layers. Leave a field blank to keep it unchanged.", '<div class="tool-card"><div class="field-row" style="justify-content:space-between;margin-bottom:12px"><span class="pill" id="transformLayerName">NO LAYER READ</span><button class="btn small" data-action="readTransform">↻ READ SELECTION</button></div><div class="field-grid"><div class="field"><label>POSITION X</label><input class="input" id="posX" placeholder="—"></div><div class="field"><label>POSITION Y</label><input class="input" id="posY" placeholder="—"></div><div class="field"><label>POSITION Z · AUTO 3D</label><input class="input" id="posZ" placeholder="Leave blank to keep 2D"></div><div class="field"><label>ROTATION °</label><input class="input" id="rot" placeholder="—"></div><div class="field"><label>SCALE X %</label><input class="input" id="scaleX" placeholder="—"></div><div class="field"><label>SCALE Y %</label><input class="input" id="scaleY" placeholder="—"></div><div class="field"><label>OPACITY %</label><input class="input" id="opacity" placeholder="—"></div></div><div class="inline-actions" style="margin-top:12px"><button class="btn primary" data-action="applyTransform">APPLY TO SELECTION</button><button class="btn" data-action="resetTransform">RESET TRANSFORM</button></div></div>');
    html += section("Nudge & flip", "Move selected 2D layers in precise increments or mirror their scale.", '<div class="tool-card"><div class="field-row"><div class="field" style="max-width:110px"><label>NUDGE AMOUNT</label><input class="input" id="nudgeAmount" value="10" type="number"></div><div class="nudge-pad"><button data-action="nudge" data-dx="-1" data-dy="-1">↖</button><button data-action="nudge" data-dx="0" data-dy="-1">↑</button><button data-action="nudge" data-dx="1" data-dy="-1">↗</button><button data-action="nudge" data-dx="-1" data-dy="0">←</button><button class="nudge-center" disabled>MOVE</button><button data-action="nudge" data-dx="1" data-dy="0">→</button><button data-action="nudge" data-dx="-1" data-dy="1">↙</button><button data-action="nudge" data-dx="0" data-dy="1">↓</button><button data-action="nudge" data-dx="1" data-dy="1">↘</button></div><div style="margin-left:auto;display:flex;flex-direction:column;gap:5px"><button class="btn small" data-action="flipX">FLIP X</button><button class="btn small" data-action="flipY">FLIP Y</button></div></div></div>');
    return html;
  }
  function renderAnimate() {
    var html = pageIntro("MOTION / 03", "Animation tools", "Build keyframes, refine timing and control layer sequencing from one focused workspace.", "KEYFRAME UTILITIES");
    html += section("Keyframe assistant", "Select keyframes in the After Effects timeline before applying interpolation.", '<div class="card-grid">' + toolCard("⌁","Easy Ease","Apply Bezier interpolation and 66 influence easing to selected keys.","ease","APPLY EASY EASE","primary") + toolCard("↔","Linear","Set selected keyframes to linear interpolation.","linear","SET LINEAR") + toolCard("＋","Add transform keys","Create position, scale, rotation and opacity keys at the playhead.","keyframes","ADD KEYFRAMES") + toolCard("⤴","Loop cycle","Apply loopOut cycle expression to selected properties.","loop","APPLY LOOP") + '</div>');
    html += section("Timing & stagger", "Sequence selected layers in their current selection order.", '<div class="tool-card"><div class="field-row"><div class="field" style="max-width:120px"><label>FRAME OFFSET</label><input class="input" id="offsetFrames" value="5" type="number"></div><button class="btn primary" data-action="stagger">STAGGER LAYERS</button><button class="btn" data-action="offset">OFFSET ALL</button></div><div class="divider"></div><div class="inline-actions"><button class="btn" data-action="trimIn">SET IN-POINT TO PLAYHEAD</button><button class="btn" data-action="trimOut">SET OUT-POINT TO PLAYHEAD</button></div></div>');
    html += section("Expression studio", "Wiggle targets selected expression properties, or selected-layer Position when no property is selected. Loop Out requires at least two keyframes.", '<div class="tool-card"><div class="field-row"><div class="field"><label>WIGGLE FREQUENCY</label><input class="input" id="wiggleFreq" value="2" min="0.01" step="0.1" type="number"></div><div class="field"><label>WIGGLE AMOUNT</label><input class="input" id="wiggleAmp" value="35" min="0" step="1" type="number"></div></div><div class="field" style="margin-top:10px"><label>TARGET</label><select class="select" id="expressionTarget"><option value="auto">Selected property, or Position fallback</option><option value="position">Selected layer Position only</option></select></div><label class="check-row"><input id="replaceExpression" type="checkbox"><span>Replace an existing expression on the target</span></label><div class="inline-actions" style="margin-top:10px"><button class="btn primary" data-action="wiggle" title="Apply wiggle to the chosen target property">APPLY WIGGLE</button><button class="btn" data-action="pingpong" title="Loop keyframed values forward and backward">LOOP PINGPONG</button><button class="btn" data-action="loop" title="Repeat keyframed values in a cycle">LOOP CYCLE</button><button class="btn danger" data-action="clearExpression" title="Remove the expression from the chosen target">CLEAR EXPRESSION</button></div><p class="muted-note">An After Effects property can have only one expression. Applying Wiggle, PingPong or Cycle replaces the previous expression only when Replace Existing Expression is checked. PingPong/Cycle need 2+ keyframes.</p></div>');
    return html;
  }
  function renderTypography() {
    var html = pageIntro("TYPE / 04", "Typography studio", "Edit text documents, preview type styles live, and build editable text animations.", "TEXT LAYER TOOLS");
    html += section("Text document", "Load a selected text layer, edit its copy and see a live preview before applying changes.", '<div class="tool-card"><div class="field"><label>TEXT CONTENT</label><textarea class="textarea" id="textContent" placeholder="Type your new headline…"></textarea></div><div class="field-grid" style="margin-top:10px"><div class="field"><label>FONT SIZE</label><input class="input" id="textSize" type="number" value="64" placeholder="e.g. 96"></div><div class="field"><label>TRACKING</label><input class="input" id="textTracking" type="number" value="0" placeholder="e.g. 20"></div><div class="field"><label>FILL HEX</label><input class="input" id="textFill" type="text" value="#FFFFFF" maxlength="7"></div><div class="field"><label>COLOUR PICKER</label><input class="input color-picker-large" id="textFillPicker" type="color" value="#ffffff"></div></div><div class="text-preview-card"><div class="preview-head"><span>LIVE TEXT PREVIEW</span><small id="textPreviewMeta">Inter · 64 PX · #FFFFFF</small></div><div class="text-preview-stage"><span id="textPreviewText">MAKE EVERY WORD MOVE.</span></div></div><div class="inline-actions" style="margin-top:11px"><button class="btn" data-action="readText">LOAD SELECTED TEXT</button><button class="btn primary" data-action="updateText">APPLY TO SELECTED TEXT LAYERS</button></div></div>');
    html += section("Character reveal", "Adds a native text animator with opacity and position selectors, animated from the current playhead.", '<div class="tool-card"><div class="field-row"><div class="field" style="max-width:135px"><label>DURATION (SECONDS)</label><input class="input" id="textDuration" value="0.8" type="number" step="0.1" min="0.01"></div><button class="btn primary" data-action="textReveal">BUILD CHARACTER REVEAL</button></div><p class="muted-note">Select one or more text layers. The generated animator remains editable in After Effects.</p></div>');
    html += section("Font pairing suggestions", "Choose a font to preview it and apply it to selected text layers. Fonts must be installed locally.", '<div class="font-suggestions">'+[["Inter-Regular","Inter · Clean product UI"],["Manrope-Regular","Manrope · Modern SaaS"],["DMSans-Regular","DM Sans · Friendly interface"],["Sora-Regular","Sora · Distinctive headlines"],["PlusJakartaSans-Regular","Plus Jakarta Sans · Premium product"],["Montserrat-SemiBold","Montserrat · Bold marketing"],["Poppins-Medium","Poppins · Rounded geometric"],["Roboto-Regular","Roboto · Neutral utility"]].map(function(f){return '<button class="font-chip" data-action="setFont" data-font="'+f[0]+'"><strong>'+f[1].split(' · ')[0]+'</strong><small>'+f[1].split(' · ')[1]+'</small></button>';}).join('')+'</div><p class="muted-note" style="margin-top:10px">Font chips also update the live preview. Applying to After Effects requires at least one selected text layer.</p>');
    html += section("Typography motion guide", "Use the Character Reveal tool above for per-character motion. For layer-wide Fade Up, Soft Zoom or Pop In, open the single shared Effects & Presets library.", '<div class="recipe-grid"><div class="recipe"><strong>CHARACTER LEVEL</strong><p>Use Character Reveal for word-by-word or character-by-character emphasis.</p></div><div class="recipe"><strong>HEADLINE</strong><p>Try Fade Up or Soft Zoom from Effects & Presets.</p></div><div class="recipe"><strong>BADGES & LABELS</strong><p>Try Pop In or Overshoot from the shared motion preset library.</p></div></div><button class="btn soft" data-page="effects" style="margin-top:10px">OPEN EFFECTS & PRESETS ↗</button>');
    return html;
  }

      function renderEffects() {
    var html=pageIntro("LIBRARY / 07","Effects & Presets","Search native After Effects effects, apply motion presets and manage effects on selected layers.","SEARCHABLE CATALOG");
    html+='<div class="tool-card catalog-search-card"><div class="search-line"><span>⌕</span><input id="catalogSearch" class="input" placeholder="Search effects and motion presets…"></div><div class="filter-chips"><button class="preset-chip active" data-filter="all">All</button><button class="preset-chip" data-filter="effect">Effects</button><button class="preset-chip" data-filter="motion">Motion presets</button></div><div id="catalogResults" class="catalog-grid">';
    effectCatalog.forEach(function(e){html+='<div class="catalog-item" data-kind="effect" data-search="'+(e[0]+" "+e[1]).toLowerCase()+'"><span class="tool-icon">✳</span><div><strong>'+e[0]+'</strong><small>'+e[1]+'</small></div><button class="btn small soft" data-action="effect" data-effect="'+e[2]+'">ADD</button></div>';});
    [["Fade Up","fade-up"],["Slide Left","slide-left"],["Soft Zoom","soft-zoom"],["Pop In","pop-in"],["Overshoot","overshoot"]].forEach(function(m){html+='<div class="catalog-item" data-kind="motion" data-search="'+m[0].toLowerCase()+'"><span class="tool-icon">⌁</span><div><strong>'+m[0]+'</strong><small>Native animated entrance</small></div><button class="btn small soft" data-action="motionPreset" data-preset="'+m[1]+'">APPLY</button></div>';});
    html+='</div></div>';
    html+=section("Effect stack controls","Enable, disable or remove effects on selected layers.",'<div class="tool-card"><div class="inline-actions"><button class="btn" data-action="enableEffects">ENABLE ALL</button><button class="btn" data-action="disableEffects">DISABLE ALL</button><button class="btn danger" data-action="removeEffects">REMOVE ALL…</button></div><p class="muted-note">Native effect availability depends on your After Effects installation. Some effects may not exist in every version.</p></div>');
    return html;
  }
  function renderTimeline() {
    var html = pageIntro("ORGANISE / 06", "Timeline & layers", "Keep complex compositions tidy with batch rename, duplicates, pre-compositions and markers.", "PROJECT HYGIENE");
    html += section("Layer structure", "Duplicate the selected layers or combine them into a new precomposition.", '<div class="card-grid">' + toolCard("▣","Duplicate selection","Create editable copies and select the duplicates.","duplicate","DUPLICATE LAYERS") + toolCard("▧","Pre-compose","Move selected layers into a new precomposition.","precompose","PRE-COMPOSE…") + '</div>');
    html += section("Batch renamer", "Find / replace is applied first, followed by prefix and suffix.", '<div class="tool-card"><div class="field-grid"><div class="field"><label>FIND</label><input class="input" id="renameFind" placeholder="Old text"></div><div class="field"><label>REPLACE WITH</label><input class="input" id="renameReplace" placeholder="New text"></div><div class="field"><label>PREFIX</label><input class="input" id="renamePrefix" placeholder="MF_"></div><div class="field"><label>SUFFIX</label><input class="input" id="renameSuffix" placeholder="_01"></div></div><button class="btn primary full" style="margin-top:10px" data-action="rename">RENAME SELECTED LAYERS</button></div>');
    html += section("Composition markers", "Add a marker at the current playhead position.", '<div class="tool-card"><div class="field-row"><div class="field"><label>MARKER COMMENT</label><input class="input" id="markerText" value="MOTIONFLOW MARKER"></div><button class="btn" data-action="marker">＋ ADD MARKER</button></div></div>');
    return html;
  }

  var colorPalettes = [
    ["NEO SAAS",["#101827","#6C7CFF","#42D6C5","#F6F8FF"]],
    ["OCEAN GLASS",["#0B1B2B","#24B8D8","#76E4D4","#D8F7FF"]],
    ["SUNSET STUDIO",["#25152B","#FF6E7F","#FFB86B","#FFE4B5"]],
    ["LAVENDER UI",["#201B35","#A78BFA","#D6BCFA","#F5F0FF"]],
    ["MONOCHROME",["#111315","#454C55","#AAB3BD","#F1F4F7"]],
    ["CYBER LIME",["#111A14","#B7F34A","#4CE0A1","#F2FFD6"]],
    ["WARM EDITORIAL",["#2B211C","#D69B65","#E9C9A6","#FFF1DE"]],
    ["BERRY PRODUCT",["#241426","#E66CBA","#A88BFF","#FBE8F5"]]
  ];
  function renderFlow() {
    var html=pageIntro("CURVE ENGINE / 04","Flow Graph","Shape the timing of selected After Effects keyframes with visual easing presets and adjustable influence.","KEYFRAME GRAPH");
    html+=section("Curve editor","Move the sliders to refine the curve. AE uses temporal influence values when applying the curve to selected keys.",'<div class="tool-card flow-editor"><div class="flow-stage"><svg id="flowSvg" viewBox="0 0 340 190" role="img" aria-label="Bezier easing curve"><defs><pattern id="flowGrid" width="34" height="19" patternUnits="userSpaceOnUse"><path d="M 34 0 L 0 0 0 19" fill="none" stroke="#27352e" stroke-width="1"/></pattern></defs><rect x="10" y="10" width="320" height="170" rx="8" fill="url(#flowGrid)"/><path d="M20 165 L320 20" class="flow-diagonal"/><path id="flowCurve" d="M20 165 C100 165 250 20 320 20" class="flow-curve"/><circle cx="20" cy="165" r="4" class="flow-point"/><circle cx="320" cy="20" r="4" class="flow-point"/><circle id="flowHandleOut" cx="100" cy="165" r="6" class="flow-handle"/><circle id="flowHandleIn" cx="250" cy="20" r="6" class="flow-handle"/></svg><div class="flow-caption"><span>START</span><span>TIME →</span><span>END</span></div></div><div class="flow-presets"><button class="preset-chip active" data-action="flowPreset" data-in="72" data-out="72">Smooth</button><button class="preset-chip" data-action="flowPreset" data-in="25" data-out="88">Ease Out</button><button class="preset-chip" data-action="flowPreset" data-in="88" data-out="25">Ease In</button><button class="preset-chip" data-action="flowPreset" data-in="90" data-out="90">Strong</button><button class="preset-chip" data-action="flowPreset" data-in="50" data-out="50">Balanced</button></div><div class="field-grid flow-sliders"><div class="field"><label>INFLUENCE IN <b id="flowInValue">72%</b></label><input id="flowIn" type="range" min="1" max="100" value="72" class="flow-range"></div><div class="field"><label>INFLUENCE OUT <b id="flowOutValue">72%</b></label><input id="flowOut" type="range" min="1" max="100" value="72" class="flow-range"></div></div><button class="btn primary full" data-action="applyFlow">APPLY TO SELECTED KEYFRAMES</button><p class="muted-note">Select keyframes (not just layers) in the AE timeline first. This editor controls temporal ease influence; it does not replace AE’s native keyframe graph editor.</p></div>');
    return html;
  }
  function motionCard(title,desc,preset,duration){return '<div class="tool-card motion-card"><div class="card-top"><span class="tool-icon">⌁</span><span class="section-tag">ANIMATION</span></div><h4>'+title+'</h4><p class="desc">'+desc+'</p><div class="field"><label>DURATION (SEC)</label><input class="input" type="number" step="0.05" min="0.05" max="10" id="dur_'+preset+'" value="'+duration+'"></div><button class="btn soft full" style="margin-top:9px" data-action="motionPreset" data-preset="'+preset+'">APPLY PRESET</button></div>';}
  function renderCopyLab() {
    var clip=null;try{clip=JSON.parse(window.localStorage.getItem("motionflow.clipboard")||"null");}catch(e){}
    var info=clip?escapeHtml(clip.name||"Copied layer style")+" · Transform" : "Clipboard is empty";
    return pageIntro("WORKFLOW / 05","Copy & Paste Lab","Copy transform and text styling from one layer, then paste it onto one or more selected layers.","STYLE TRANSFER")+
      section("Layer style clipboard","Copy from one selected layer, select your target layers, and paste. Unsupported animated properties are skipped safely.",'<div class="tool-card"><div class="clipboard-state"><span class="clipboard-icon">▣</span><div><strong id="clipboardName">'+info+'</strong><small>Local clipboard · saved between sessions</small></div><span class="pill">'+(clip?"READY":"EMPTY")+'</span></div><div class="inline-actions" style="margin-top:14px"><button class="btn primary" data-action="copyTransform">COPY SELECTED LAYER</button><button class="btn" data-action="pasteTransform" '+(clip?'':'disabled')+'>PASTE TO SELECTION</button><button class="btn danger" data-action="clearClipboard">CLEAR</button></div><p class="muted-note">Includes position, scale, rotation, opacity and text font/size/tracking/fill when the source is a text layer.</p></div>')+
      section("Save a reusable preset","Store a transform snapshot locally and access it later in My Saved Presets.",'<div class="tool-card"><p class="desc">Select a reference layer and save its static transform as a reusable preset.</p><button class="btn primary full" data-action="savePreset">＋ SAVE CURRENT LAYER AS PRESET</button><button class="btn full" data-page="saved" style="margin-top:8px">OPEN MY SAVED PRESETS ↗</button></div>');
  }
  function renderColors() {
    var html=pageIntro("DESIGN SYSTEM / 06","Color Studio","Choose a colour for actual layer fills without changing the plugin theme. Accent colour is a separate setting.","PALETTE LIBRARY");
    colorPalettes.forEach(function(p,i){html+= '<div class="palette-card"><div class="palette-head"><div><strong>'+p[0]+'</strong><small>CLICK ANY SWATCH TO SELECT A LAYER FILL</small></div><button class="btn small soft" data-action="usePalette" data-palette="'+i+'">LOAD PALETTE</button></div><div class="palette-swatches">'+p[1].map(function(c){return '<button class="palette-swatch" data-action="useColor" data-color="'+c+'" title="Select fill '+c+'" style="--palette-color:'+c+'"><span></span><code>'+c+'</code></button>';}).join('')+'</div></div>';});
    html+=section("Apply colour to the project","Apply the selected HEX colour to solid sources, editable shape fills and text fills on selected layers.",'<div class="tool-card"><div class="field-row"><div class="field"><label>SELECTED FILL HEX</label><input class="input" id="paletteHex" value="'+currentFillHex()+'" maxlength="7"></div><div class="field" style="max-width:64px"><label>PICKER</label><input type="color" id="palettePicker" value="'+currentFillHex().toLowerCase()+'" class="input color-picker-large"></div></div><div class="colour-preview-strip"><span id="fillPreviewSwatch" style="background:'+currentFillHex()+'"></span><div><b>Current layer fill</b><small id="fillPreviewLabel">'+currentFillHex()+'</small></div></div><div class="inline-actions"><button class="btn primary" data-action="applySelectionColor">APPLY TO SELECTED LAYERS</button><button class="btn" data-action="setAccentFromFill">SET AS UI ACCENT</button></div><p class="muted-note">Applying fill recolours solid footage sources, shape-layer fills and text fills. Unsupported layers are skipped. Set as UI Accent only changes the panel appearance.</p></div>');
    return html;
  }

      var effectCatalog = [
    ["Glow","Stylised highlight bloom","glow","ADBE Glo2"],["Gaussian Blur","Soft focus and depth","blur","ADBE Gaussian Blur 2"],["Drop Shadow","Lift cards and floating UI","shadow","ADBE Drop Shadow"],["Tint","Map a layer to two tones","tint","ADBE Tint"],["Fill","Apply a solid colour","fill","ADBE Fill"],["Motion Tile","Extend edges for motion","motionTile","ADBE Motion Tile"],["Turbulent Displace","Organic liquid distortion","turbulent","ADBE Turbulent Displace"],["Sharpen","Increase edge clarity","sharpen","ADBE Sharpen"],["Mosaic","Pixel-grid styling","mosaic","ADBE Mosaic"],["Noise","Add subtle texture","noise","ADBE Noise"],["Posterize Time","Stylised stepped frame rate","posterize","ADBE Posterize Time"],["Bevel Alpha","Edge depth treatment","bevel","ADBE Bevel Alpha"]
  ];
  function renderSavedPresets() {
    var saved=[];try{saved=JSON.parse(window.localStorage.getItem("motionflow.presets")||"[]");if(!(saved instanceof Array))saved=[];}catch(e){saved=[];}
    var html=pageIntro("LIBRARY / 08","My Saved Presets","Your personal collection of reusable static transform presets, stored on this computer.","LOCAL LIBRARY");
    if(!saved.length) html+='<div class="empty-library"><span>◇</span><h3>Your preset library is ready.</h3><p>Save a selected layer from Copy & Paste Lab to start building your own transform toolkit.</p><button class="btn primary" data-page="copylab">SAVE MY FIRST PRESET</button></div>';
    else html+='<div class="saved-list">'+saved.map(function(v,i){return '<div class="saved-preset"><div class="preset-mark">✦</div><div class="preset-meta"><strong>'+escapeHtml(v.name)+'</strong><small>'+escapeHtml(v.source||"Layer snapshot")+' · '+escapeHtml(v.date||"")+'</small><small>Scale '+escapeHtml(v.sx)+' × '+escapeHtml(v.sy)+' · Opacity '+escapeHtml(v.opacity)+'%</small></div><button class="btn small primary" data-action="applySaved" data-index="'+i+'">APPLY</button><button class="btn small danger" data-action="deleteSaved" data-index="'+i+'">×</button></div>';}).join('')+'</div>';
    return html+section("Preset workflow","Save a static transform snapshot from Copy / Paste Lab. Animation presets live in Effects & Presets to avoid duplicate tools.",'<div class="tool-card"><button class="btn primary" data-page="effects">OPEN EFFECTS & PRESETS</button></div>');
  }
  function renderSaaS() {
    var html=pageIntro("PRODUCT MOTION / 09","SaaS Motion Lab","Build editable product UI elements, glass cards, metrics, CTAs and dashboard scenes directly in After Effects.","EDITABLE AE LAYERS");
    html+=section("Glass material","Choose how much backdrop blur and surface tint to use. Put footage, a detailed image or a textured composition underneath the generated glass.",'<div class="tool-card glass-material-picker"><div class="material-options"><label class="material-option"><input type="radio" name="glassMaterial" value="clear"><span class="material-preview clear-preview"></span><b>Clear</b><small>Light blur · low tint</small></label><label class="material-option active"><input type="radio" name="glassMaterial" value="frosted" checked><span class="material-preview frosted-preview"></span><b>Frosted</b><small>Balanced blur · soft edge</small></label><label class="material-option"><input type="radio" name="glassMaterial" value="tinted"><span class="material-preview tinted-preview"></span><b>Tinted</b><small>Deep blur · stronger tint</small></label></div><div class="field-row" style="margin-top:12px"><div class="field"><label>GLASS TINT HEX</label><input class="input" id="glassTintHex" value="#B9E8FF" maxlength="7"></div><div class="field" style="max-width:62px"><label>PREVIEW</label><input class="input color-picker-large" id="glassTintPicker" type="color" value="#b9e8ff"></div></div><p class="muted-note">Glass material changes the generated blur strength, fill opacity and border treatment. This is native masked Gaussian Blur + editable translucent layers, not a fake opaque card.</p></div><div class="card-grid">'+saasCard("Glass Card","Translucent panel with title, content and specular edge highlights","glass-card","CREATE GLASS CARD")+saasCard("Metric Card","SaaS KPI card with value and growth indicator","metric","CREATE METRIC CARD")+saasCard("CTA Button","Rounded call-to-action button with label","cta","CREATE CTA BUTTON")+saasCard("Dashboard Scene","Hero panel and three editable metric cards","dashboard","CREATE DASHBOARD")+saasCard("Toggle Switch","Animated toggle with label","toggle","CREATE TOGGLE")+saasCard("Browser Window","Glass browser frame with product heading","browser","CREATE BROWSER WINDOW")+'</div>');
    html+=section("Product animation recipes","Use these starting points for clean, modern product storytelling.",'<div class="recipe-grid"><div class="recipe"><strong>SAAS HERO</strong><p>Headline → 0.65s Fade Up</p><p>Supporting copy → 0.75s Fade Up</p><p>CTA → 0.42s Pop In</p></div><div class="recipe"><strong>DASHBOARD REVEAL</strong><p>Glass panel → 0.7s Soft Zoom</p><p>KPI cards → 0.55s Stagger</p><p>Numbers → 0.45s Fade Up</p></div><div class="recipe"><strong>MICRO-INTERACTION</strong><p>Button → Pop In</p><p>Toggle → Scale 90–100%</p><p>Tooltip → Fade Up</p></div></div>');
    html+='<div class="warning-note" style="margin-top:12px">Liquid glass is built from native masked Gaussian Blur adjustment layers plus low-opacity vector surfaces. It needs visible footage or artwork beneath it. All shapes, text and keyframes remain editable.</div>';
    return html;
  }
  function saasCard(title,desc,template,label){return '<div class="tool-card saas-card"><div class="card-top"><span class="tool-icon">◇</span><span class="section-tag">NATIVE LAYERS</span></div><h4>'+title+'</h4><p class="desc">'+desc+'</p><button class="btn soft full" data-action="createSaaS" data-template="'+template+'">'+label+'</button></div>';}

  function renderUtilities() {
    var html = pageIntro("SYSTEM / 07", "Utilities & info", "Quick maintenance, host status and keyboard shortcuts for the MotionFlow workspace.", "WORKFLOW TOOLS");
    html += section("Live project details", "This data is read from the current After Effects composition.", '<div class="tool-card"><div class="field-grid"><div class="field"><label>COMPOSITION</label><div class="pill" id="utilComp">—</div></div><div class="field"><label>DIMENSIONS</label><div class="pill" id="utilSize">—</div></div><div class="field"><label>FRAME RATE</label><div class="pill" id="utilFps">—</div></div><div class="field"><label>PLAYHEAD</label><div class="pill" id="utilTime">—</div></div><div class="field"><label>TOTAL LAYERS</label><div class="pill" id="utilLayers">—</div></div><div class="field"><label>SELECTED LAYERS</label><div class="pill" id="utilSelected">—</div></div></div><button class="btn primary" style="margin-top:12px" data-action="refresh">↻ REFRESH PROJECT INFO</button></div>');
    html += section("Keyboard shortcuts", "Use the search field to quickly find and run commands.", '<div class="tool-card"><div class="effect-row"><div class="effect-info"><strong>Command search</strong><small>Focus the tool finder</small></div><kbd class="shortcut">CTRL + K</kbd></div><div class="effect-row"><div class="effect-info"><strong>Run search command</strong><small>Execute the first matching result</small></div><kbd class="shortcut">ENTER</kbd></div><div class="effect-row"><div class="effect-info"><strong>Refresh composition</strong><small>Update active comp and selection data</small></div><kbd class="shortcut">BUTTON</kbd></div></div>');
    html += '<div class="warning-note" style="margin-top:12px">Not included as completed features: AI generation, offline transcription, geographic map rendering, rotoscoping, third-party asset search and a full Bezier curve engine. These require separate integrations and are not simulated in this build.</div>';
    return html;
  }
  function renderHelp() {
    var html=pageIntro("SUPPORT / 13","Guide & About","A quick guide to MotionFlow tools, safe workflows and what this build can do.","HELP CENTRE");
    html+=section("Quick start guides","Short instructions for the tools that are easiest to misread.",'<div class="guide-grid"><article class="guide-card"><b>01 · Create & colour</b><p>Open Create, choose a HEX fill, then create a Solid, Rectangle or Ellipse. In Color Studio, clicking a swatch syncs the fill HEX and preview and applies it to supported selected layers. With no selection it sets the current fill for later creation; Apply to Selected Layers applies it manually.</p></article><article class="guide-card"><b>02 · Position Z</b><p>Enter a Z value and Apply. MotionFlow automatically enables 3D on selected 2D layers and keeps their X/Y positions. Existing animated or separated Position properties are skipped for safety.</p></article><article class="guide-card"><b>03 · Expressions</b><p>Wiggle works on selected expression properties, or the selected layer Position when none are selected. PingPong/Cycle require two or more keyframes. Only one expression can be active per property.</p></article><article class="guide-card"><b>04 · Typography</b><p>Type into Text Content to preview live. Load Selected Text to read the first selected text layer. Apply to Selected Text Layers writes the document changes into After Effects.</p></article><article class="guide-card"><b>05 · Liquid Glass</b><p>Create a Glass Card over footage or a background layer. MotionFlow adds a masked Gaussian Blur adjustment layer behind a translucent vector surface. A blank/transparent area beneath it cannot produce visible blur.</p></article><article class="guide-card"><b>06 · Saved presets</b><p>Copy / Paste Lab stores a static transform snapshot in local panel storage. It is local to this Windows user and panel profile; it does not embed presets into the project file.</p></article></div>');
    html+=section("Workspace guide","What each workspace is for. Hover any action button for a reminder before running it.",'<div class="guide-grid"><article class="guide-card"><b>Overview & Create</b><p>Overview shows the active composition snapshot. Create adds native Null, 3D Null, Solid, Adjustment, Text, Rectangle, Ellipse, Camera and Light layers. Solid/shape colour comes from the separate project-fill setting.</p></article><article class="guide-card"><b>Transform & Animate</b><p>Transform edits static position, scale, rotation and opacity; entering Z enables 3D. Animate includes anchor, align, offset, stagger, trim, keyframe utilities, expressions and entrance presets.</p></article><article class="guide-card"><b>Flow Graph</b><p>Choose an easing preset or drag the two handles, then select keyframes in the AE timeline and apply the in/out influence. It edits temporal ease influence, not spatial paths.</p></article><article class="guide-card"><b>Copy / Paste & Saved Presets</b><p>Copy captures a static transform and optional text styling. Paste applies it to selected targets. Save stores transform snapshots in this computer&#39;s panel storage, not inside the AEP file.</p></article><article class="guide-card"><b>Color Studio & Typography</b><p>Color swatches sync the project fill HEX and preview and apply to supported selected layers when available. Apply to Selected Layers can be used manually. UI Accent changes only the panel. Typography has a live preview, selected-text reader, text apply and local font suggestions.</p></article><article class="guide-card"><b>Effects, Timeline & Utilities</b><p>Effects adds installed native effects and manages their enabled state. Timeline duplicates, pre-composes, batch-renames and adds markers. Utilities reports the active comp and refreshes host information.</p></article><article class="guide-card"><b>SaaS Motion Lab</b><p>Creates editable shape/text interface components and native entrance keyframes. Glass cards use a masked Gaussian Blur adjustment layer with translucent vector surfaces; visible footage/artwork must sit below the glass.</p></article><article class="guide-card"><b>Selection & Undo</b><p>Select the intended layers before running layer tools. Select actual timeline keyframes before applying Flow Graph/Easy Ease. Each host operation is placed in an After Effects undo group.</p></article></div>');
    html+=section("Tool behaviour & safety","Hover over tool buttons for concise help. Destructive or potentially lossy operations use confirmation or refuse animated properties.",'<div class="tool-card"><div class="effect-row"><div class="effect-info"><strong>Undo</strong><small>Host operations are grouped into After Effects undo steps.</small></div><kbd>CTRL + Z</kbd></div><div class="effect-row"><div class="effect-info"><strong>Command search</strong><small>Search and run available tools across the panel.</small></div><kbd>CTRL + K</kbd></div><div class="effect-row"><div class="effect-info"><strong>Run selected search result</strong><small>Press Enter to run the first matching command.</small></div><kbd>ENTER</kbd></div></div>');
    html+=section("About MOTIONFLOW PRO","Version and compatibility details.",'<div class="about-card"><div class="about-mark">MF</div><div class="about-copy"><h3>MOTIONFLOW PRO</h3><p>Independent motion-design toolkit for Adobe After Effects.</p><span>STUDIO SUITE · VERSION 0.8.0 · CEP PANEL + EXTENDSCRIPT HOST</span></div></div><div class="tool-card about-details"><div><small>SUPPORTED HOST</small><b>Adobe After Effects 2025 (25.x) and compatible later releases</b></div><div><small>PROJECT DATA</small><b>Native layers, properties, effects and keyframes remain editable</b></div><div><small>LIMITATIONS</small><b>No bundled AI, transcription service or third-party plugin dependency. Font choices require local installation.</b></div></div>');
    return html;
  }

  var pageRenderers = { home:renderHome, create:renderCreate, transform:renderTransform, animate:renderAnimate, flow:renderFlow, copylab:renderCopyLab, colors:renderColors, typography:renderTypography, effects:renderEffects, saved:renderSavedPresets, saas:renderSaaS, timeline:renderTimeline, utilities:renderUtilities, help:renderHelp };
  var pageNames = { home:["OVERVIEW","Make motion happen."], create:["CREATE","Build something new."], transform:["TRANSFORM","Precision in every move."], animate:["ANIMATE","Shape the timing."], flow:["FLOW GRAPH","Control the curve."], copylab:["COPY / PASTE","Reuse your best work."], colors:["COLOR STUDIO","Build a visual system."], typography:["TYPOGRAPHY","Make every word move."], effects:["EFFECTS & PRESETS","Find your next look."], saved:["MY SAVED PRESETS","Your personal library."], saas:["SAAS MOTION LAB","Design product stories."], timeline:["TIMELINE","Keep the project clean."], utilities:["UTILITIES","Your workflow, in control."], help:["GUIDE & ABOUT","Know your tools. Work with confidence."] };
  function openPage(name) {
    if (!pageRenderers[name]) return;
    activePage = name;
    Array.prototype.forEach.call(document.querySelectorAll(".nav-item"), function (b) { b.classList.toggle("active", b.getAttribute("data-page") === name); });
    $("pageContent").innerHTML = pageRenderers[name]();
    $("crumbName").textContent = pageNames[name][0]; $("pageTitle").textContent = pageNames[name][1];
    $("pageScroll").scrollTop = 0;
    updateHomeStats(); updateUtilities();
    if (name === "flow") updateFlowGraph();
    if (name === "effects") filterCatalog();
    if (name === "typography") updateTextPreview();
    if (name === "saas") syncGlassMaterialUI();
  }
  function updateUtilities() {
    var fields = { utilComp:context.hasComp?context.comp:"—", utilSize:context.hasComp?context.width+" × "+context.height:"—", utilFps:context.hasComp?Number(context.fps).toFixed(3)+" FPS":"—", utilTime:context.hasComp?Number(context.time).toFixed(2)+"s":"—", utilLayers:context.hasComp?context.layers:"—", utilSelected:context.hasComp?context.selected:"—" };
    Object.keys(fields).forEach(function (id) { var el=$(id);if(el)el.textContent=fields[id]; });
  }
  function refreshAll() { refreshContext(); }
  function goPage(name) { openPage(name); }

  function currentGlassMaterial(){var r=document.querySelector("input[name=glassMaterial]:checked");if(r)return r.value;try{return window.localStorage.getItem("motionflow.glassMaterial")||"frosted";}catch(e){return "frosted";}}
  function currentGlassTint(){var raw=$("glassTintHex")?$("glassTintHex").value:"#B9E8FF";return /^#?[0-9a-fA-F]{6}$/.test(raw)?normaliseHex(raw):raw;}
  function syncGlassMaterialUI(){var saved="frosted";try{saved=window.localStorage.getItem("motionflow.glassMaterial")||"frosted";}catch(e){}var nodes=document.querySelectorAll("input[name=glassMaterial]");Array.prototype.forEach.call(nodes,function(n){if(n.value===saved)n.checked=true;var p=n.closest?n.closest(".material-option"):null;if(p)p.classList.toggle("active",n.checked);});var tint="";try{tint=window.localStorage.getItem("motionflow.glassTint")||"";}catch(e2){}if(tint&&$("glassTintHex"))$("glassTintHex").value=tint;if($("glassTintPicker")&&$("glassTintHex"))$("glassTintPicker").value=currentGlassTint().toLowerCase();}
  function precompose() { var name=window.prompt("Name the new precomposition:","MF_Precomp"); if(name===null || !name.replace(/\s/g,""))return; invoke("precompose",[name]); }
  function runAction(action, el) {
    var kind, amount, value;
    switch (action) {
      case "createNull": invoke("create",["Null",currentAccentHex().slice(1)]); break;
      case "create3DNull": invoke("create",["3D Null",currentAccentHex().slice(1)]); break;
      case "createSolid": invoke("create",["Solid",($("solidHex")?$("solidHex").value:currentFillHex())]); break;
      case "createCustomSolid": invoke("create",["Solid",$("solidHex").value]); break;
      case "createAdjustment": invoke("create",["Adjustment",currentAccentHex().slice(1)]); break;
      case "createText": invoke("create",["Text",currentAccentHex().slice(1)]); break;
      case "createRectangle": invoke("create",["Rectangle",($("solidHex")?$("solidHex").value:currentFillHex())]); break;
      case "createEllipse": invoke("create",["Ellipse",($("solidHex")?$("solidHex").value:currentFillHex())]); break;
      case "createCamera": invoke("create",["Camera",currentAccentHex().slice(1)]); break;
      case "createLight": invoke("create",["Light",currentAccentHex().slice(1)]); break;
      case "anchor": invoke("anchor",[el.getAttribute("data-x"),el.getAttribute("data-y")]); break;
      case "align": invoke("align",[el.getAttribute("data-mode")]); break;
      case "readTransform": invoke("getTransform",[],function (data) { if(!data.ok)return; ["posX","posY","posZ","scaleX","scaleY","rot","opacity"].forEach(function (id) { $(id).value=data[{posX:"x",posY:"y",posZ:"z",scaleX:"sx",scaleY:"sy",rot:"rotation",opacity:"opacity"}[id]]; }); $("transformLayerName").textContent=data.name+(data.threeD?" · 3D":" · 2D (Z auto-enables 3D)"); }); break;
      case "applyTransform": invoke("applyTransform",[ $("posX").value,$("posY").value,$("posZ").value,$("scaleX").value,$("scaleY").value,$("rot").value,$("opacity").value ]); break;
      case "nudge": invoke("nudge",[el.getAttribute("data-dx"),el.getAttribute("data-dy"),$("nudgeAmount").value || "10"]); break;
      case "flipX": invoke("flip",["X"]); break;
      case "flipY": invoke("flip",["Y"]); break;
      case "resetTransform": if(window.confirm("Reset selected layers to comp-centre, 100% scale, 0° rotation and 100% opacity? Animated or expression-driven properties are skipped."))invoke("reset",[]); break;
      case "ease": invoke("ease",["false"]); break;
      case "linear": invoke("ease",["true"]); break;
      case "keyframes": invoke("addKeyframes",[]); break;
      case "offset": invoke("offset",[$("offsetFrames").value || "5","false"]); break;
      case "stagger": invoke("offset",[$("offsetFrames").value || "5","true"]); break;
      case "trimIn": invoke("trim",["in"]); break;
      case "trimOut": invoke("trim",["out"]); break;
      case "wiggle": invoke("expression",["wiggle",$("wiggleFreq").value || "2",$("wiggleAmp").value || "35",$("replaceExpression").checked?"true":"false",$("expressionTarget").value]); break;
      case "loop": invoke("expression",["cycle","0","0",$("replaceExpression").checked?"true":"false",$("expressionTarget").value]); break;
      case "pingpong": invoke("expression",["pingpong","0","0",$("replaceExpression").checked?"true":"false",$("expressionTarget").value]); break;
      case "clearExpression": invoke("clearExpression",[$("expressionTarget").value]); break;
      case "updateText": invoke("updateText",[$("textContent").value,$("textSize").value,$("textTracking").value,$("textFill").value]); break;
      case "readText": readSelectedText(); break;
      case "textReveal": invoke("textReveal",[$("textDuration").value || "0.8"]); break;
      case "effect": kind=effectNames[el.getAttribute("data-effect")]; if(kind)invoke("addEffect",[kind[0],kind[1]]); break;
      case "enableEffects": invoke("toggleEffects",["true"]); break;
      case "disableEffects": invoke("toggleEffects",["false"]); break;
      case "removeEffects": if(window.confirm("Remove ALL effects from selected layers? This is destructive, but After Effects Undo can reverse it."))invoke("removeEffects",[]); break;
      case "duplicate": invoke("duplicate",[]); break;
      case "precompose": precompose(); break;
      case "rename": invoke("rename",[$("renameFind").value,$("renameReplace").value,$("renamePrefix").value,$("renameSuffix").value]); break;
      case "marker": invoke("marker",[$("markerText").value]); break;
      case "copyTransform": invoke("getTransform",[],function(data){ if(!data.ok)return; var clip=data; invoke("getTextSnapshot",[],function(td){ if(td&&td.ok){ for(var k in td)if(td.hasOwnProperty(k))clip[k]=td[k]; } try{window.localStorage.setItem("motionflow.clipboard",JSON.stringify(clip));}catch(e){} toast("Copied transform and text style from "+(clip.name||"selected layer")+"."); if(activePage==="copylab")openPage("copylab"); },true); }); break;
      case "pasteTransform": var cp=null;try{cp=JSON.parse(window.localStorage.getItem("motionflow.clipboard")||"null");}catch(e){} if(!cp){toast("Clipboard is empty. Copy a layer first.",true);break;} invoke("applySnapshot",[cp.x,cp.y,cp.z,cp.sx,cp.sy,cp.rotation,cp.opacity,cp.font||"",cp.fontSize||"",cp.tracking||"",cp.fillHex||"" ]); break;
      case "clearClipboard": try{window.localStorage.removeItem("motionflow.clipboard");}catch(e){} toast("MotionFlow clipboard cleared."); if(activePage==="copylab")openPage("copylab"); break;
      case "savePreset": invoke("getTransform",[],function(data){if(!data.ok)return;var name=window.prompt("Name this preset:",data.name+" Style");if(name===null||!name.replace(/\s/g,""))return;var items=[];try{items=JSON.parse(window.localStorage.getItem("motionflow.presets")||"[]");}catch(e){}items.push({name:name,source:data.name,date:new Date().toLocaleDateString(),x:data.x,y:data.y,z:data.z,sx:data.sx,sy:data.sy,rotation:data.rotation,opacity:data.opacity});try{window.localStorage.setItem("motionflow.presets",JSON.stringify(items));}catch(e){}toast("Saved preset: "+name);}); break;
      case "applySaved": var items=[];try{items=JSON.parse(window.localStorage.getItem("motionflow.presets")||"[]");}catch(e){} var si=Number(el.getAttribute("data-index")),sp=items[si];if(sp)invoke("applyTransform",[sp.x,sp.y,sp.z,sp.sx,sp.sy,sp.rotation,sp.opacity]);break;
      case "deleteSaved": var items2=[];try{items2=JSON.parse(window.localStorage.getItem("motionflow.presets")||"[]");}catch(e){}items2.splice(Number(el.getAttribute("data-index")),1);try{window.localStorage.setItem("motionflow.presets",JSON.stringify(items2));}catch(e){}toast("Preset deleted.");openPage("saved");break;
      case "applyFlow": invoke("easeWithInfluence",[$("flowIn").value,$("flowOut").value]); break;
      case "flowPreset": if($("flowIn"))$("flowIn").value=el.getAttribute("data-in");if($("flowOut"))$("flowOut").value=el.getAttribute("data-out");updateFlowGraph();Array.prototype.forEach.call(document.querySelectorAll(".flow-presets .preset-chip"),function(b){b.classList.toggle("active",b===el);});break;
      case "motionPreset": var preset=el.getAttribute("data-preset"),dur=$("dur_"+preset);invoke("applyMotionPreset",[preset,dur?dur.value:"0.65"]);break;
      case "useColor": var col=setCurrentFill(el.getAttribute("data-color"),true);syncFillFields(col);if($("fillPreviewSwatch"))$("fillPreviewSwatch").style.background=col;if($("fillPreviewLabel"))$("fillPreviewLabel").textContent=col;if(context.hasComp&&context.selected>0){invoke("applyColorToSelection",[col]);}else{toast("Layer fill selected: "+col+". Select layers to apply it to existing objects.");}break;
      case "usePalette": var pi=Number(el.getAttribute("data-palette"));if(colorPalettes[pi]){var paletteFill=setCurrentFill(colorPalettes[pi][1][1],true);syncFillFields(paletteFill);if($("fillPreviewSwatch"))$("fillPreviewSwatch").style.background=paletteFill;if($("fillPreviewLabel"))$("fillPreviewLabel").textContent=paletteFill;if(context.hasComp&&context.selected>0){invoke("applyColorToSelection",[paletteFill]);}else{toast(colorPalettes[pi][0]+" loaded. Its primary colour is now selected as the current fill.");}}break;
      case "applyCustomPalette": var custom=$("paletteHex").value;if(!/^#?[0-9a-fA-F]{6}$/.test(custom)){toast("Enter a valid 6-digit HEX colour.",true);break;}custom=setCurrentFill(custom,true);syncFillFields(custom);toast("Current layer fill set to "+custom+".");break;
      case "applySelectionColor": invoke("applyColorToSelection",[currentFillHex()]);break;
      case "setAccentFromFill": applyAccent(currentFillHex(),true);toast("Panel accent updated. Project fill colour is unchanged.");break;
      case "setFont": previewFont=el.getAttribute("data-font").replace(/[-_](Regular|Medium|Bold|SemiBold|Light)$/i,"");updateTextPreview();invoke("setFont",[el.getAttribute("data-font"),$("textSize")?$("textSize").value:"",$("textTracking")?$("textTracking").value:"",$("textFill")?$("textFill").value:"#FFFFFF"]);break;
      case "createSaaS": if(!/^#?[0-9a-fA-F]{6}$/.test(currentGlassTint())){toast("Enter a valid 6-digit glass tint HEX colour.",true);break;}invoke("createSaaSComponent",[el.getAttribute("data-template"),currentAccentHex().slice(1),currentGlassMaterial(),currentGlassTint().replace(/^#/,"")]);break;
      case "pageFlow": goPage("flow");break;
      case "pageSaved": goPage("saved");break;
      case "pageColors": goPage("colors");break;
      case "refresh": refreshAll(); toast("Project information refreshed."); break;
      case "pageTransform": goPage("transform"); break;
      case "pageTimeline": goPage("timeline"); break;
      case "pageEffects": goPage("effects"); break;
    }
  }
  function findCommand(query) {
    query = query.toLowerCase().replace(/^\s+|\s+$/g, "");
    if(!query)return [];
    return commands.filter(function (c) { return c[0].toLowerCase().indexOf(query)>=0 || c[1].toLowerCase().indexOf(query)>=0; }).slice(0,8);
  }
  function showResults() {
    var box=$("commandResults");
    if(!box){box=document.createElement("div");box.id="commandResults";box.className="command-results";$("commandSearch").parentNode.appendChild(box);}
    var hits=findCommand($("commandSearch").value);
    if(!hits.length){box.classList.remove("show");return;}
    box.innerHTML=hits.map(function (c) { return '<button class="result-item" data-command="'+c[2]+'"><span>'+escapeHtml(c[0])+'</span><small>'+escapeHtml(c[1])+'</small></button>'; }).join("");box.classList.add("show");
  }
  function executeCommand(action) {
    var pseudo={getAttribute:function(n){return null;}};
    if(action==="createNull")runAction("createNull",pseudo);
    else if(action==="create3DNull")runAction("create3DNull",pseudo);
    else if(action==="createSolid")runAction("createSolid",pseudo);
    else if(action==="createAdjustment")runAction("createAdjustment",pseudo);
    else if(action==="createText")runAction("createText",pseudo);
    else if(action==="createRectangle")runAction("createRectangle",pseudo);
    else if(action==="createEllipse")runAction("createEllipse",pseudo);
    else if(action==="duplicate")runAction("duplicate",pseudo);
    else if(action==="precompose")runAction("precompose",pseudo);
    else if(action==="ease")runAction("ease",pseudo);
    else if(action==="keyframes")runAction("keyframes",pseudo);
    else if(action==="textReveal"){goPage("typography");toast("Choose the reveal duration, then build the text animation.");}
    else if(effectNames[action])invoke("addEffect",effectNames[action]);
    else if(action==="refresh")runAction("refresh",pseudo);
    else if(action==="pageFlow")goPage("flow"); else if(action==="pageSaved")goPage("saved"); else if(action==="pageColors")goPage("colors"); else if(action==="pageHelp")goPage("help"); else if(action==="copyTransform"||action==="pasteTransform"||action==="applySelectionColor"||action==="clearExpression"||action==="setAccentFromFill")runAction(action,pseudo); else if(action==="saasGlass"){goPage("saas");} else if(action==="glow"||action==="blur")invoke("addEffect",effectNames[action]);
  }

  function updateFlowGraph(){
    var a=$("flowOut"),b=$("flowIn"),path=$("flowCurve"),ho=$("flowHandleOut"),hi=$("flowHandleIn");if(!a||!b||!path)return;
    var out=Number(a.value),inn=Number(b.value),x1=20+out*1.25,x2=320-inn*1.25,y1=165-(100-out)*1.45,y2=20+(100-inn)*1.45;
    path.setAttribute("d","M20 165 C"+x1+" "+y1+" "+x2+" "+y2+" 320 20");ho.setAttribute("cx",x1);ho.setAttribute("cy",y1);hi.setAttribute("cx",x2);hi.setAttribute("cy",y2);
    if($("flowOutValue"))$("flowOutValue").textContent=out+"%";if($("flowInValue"))$("flowInValue").textContent=inn+"%";
  }
  (function enableFlowHandleDrag(){
    var dragging="";
    document.addEventListener("mousedown",function(e){if(e.target&&e.target.id==="flowHandleOut")dragging="out";else if(e.target&&e.target.id==="flowHandleIn")dragging="in";});
    document.addEventListener("mousemove",function(e){if(!dragging)return;var svg=$("flowSvg");if(!svg)return;var r=svg.getBoundingClientRect(),x=(e.clientX-r.left)*340/r.width;var value=dragging==="out"?(x-20)/1.25:(320-x)/1.25;value=Math.max(1,Math.min(100,Math.round(value)));var input=$(dragging==="out"?"flowOut":"flowIn");if(input){input.value=value;updateFlowGraph();}});
    document.addEventListener("mouseup",function(){dragging="";});
  })();
  function filterCatalog(){var q=$("catalogSearch")?$("catalogSearch").value.toLowerCase():"",filter=document.querySelector(".filter-chips .active"),kind=filter?filter.getAttribute("data-filter"):"all";Array.prototype.forEach.call(document.querySelectorAll(".catalog-item"),function(it){var visible=(kind==="all"||it.getAttribute("data-kind")===kind)&&it.getAttribute("data-search").indexOf(q)>=0;it.style.display=visible?"flex":"none";});}

  document.addEventListener("click",function(e){
    var page=e.target.closest ? e.target.closest("[data-page]") : null;
    if(page){goPage(page.getAttribute("data-page"));return;}
    var result=e.target.closest ? e.target.closest("[data-command]") : null;
    if(result){executeCommand(result.getAttribute("data-command"));$("commandResults").classList.remove("show");$("commandSearch").value="";return;}
    var action=e.target.closest ? e.target.closest("[data-action]") : null;
    if(action){runAction(action.getAttribute("data-action"),action);}
  });
  $("refreshBtn").addEventListener("click",refreshAll);
  $("commandSearch").addEventListener("input",showResults);
  $("commandSearch").addEventListener("keydown",function(e){if(e.key==="Enter"){var hits=findCommand(this.value);if(hits.length){executeCommand(hits[0][2]);$("commandResults").classList.remove("show");this.value="";}}if(e.key==="Escape")$("commandResults").classList.remove("show");});
  $("searchRun").addEventListener("click",function(){var hits=findCommand($("commandSearch").value);if(hits.length)executeCommand(hits[0][2]);else toast("No matching command. Try ‘create null’, ‘easy ease’ or ‘glow’.",true);$("commandResults").classList.remove("show");});
  document.addEventListener("keydown",function(e){if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){e.preventDefault();$("commandSearch").focus();$("commandSearch").select();}});
  document.addEventListener("click",function(e){if(!e.target.closest || !e.target.closest(".search-wrap")){var r=$("commandResults");if(r)r.classList.remove("show");}});
  document.addEventListener("input",function(e){
    if(!e.target)return;var id=e.target.id,value=e.target.value;
    if(id==="flowIn"||id==="flowOut")updateFlowGraph();
    if(id==="catalogSearch")filterCatalog();
    if(id==="solidColor"||id==="palettePicker") { value=setCurrentFill(value,true);syncFillFields(value);if($("fillPreviewSwatch"))$("fillPreviewSwatch").style.background=value;if($("fillPreviewLabel"))$("fillPreviewLabel").textContent=value; }
    if(id==="solidHex"||id==="paletteHex") if(/^#?[0-9a-fA-F]{6}$/.test(value)){value=setCurrentFill(value,true);syncFillFields(value);if($("fillPreviewSwatch"))$("fillPreviewSwatch").style.background=value;if($("fillPreviewLabel"))$("fillPreviewLabel").textContent=value;}
    if(id==="textContent"||id==="textSize"||id==="textTracking"||id==="textFill"){if(id==="textFill"&&/^#?[0-9a-fA-F]{6}$/.test(value)&&$("textFillPicker"))$("textFillPicker").value=normaliseHex(value).toLowerCase();updateTextPreview();}
    if(id==="textFillPicker"&&$("textFill")){$("textFill").value=value.toUpperCase();updateTextPreview();}
    if(id==="glassTintHex"&&/^#?[0-9a-fA-F]{6}$/.test(value)){if($("glassTintPicker"))$("glassTintPicker").value=normaliseHex(value).toLowerCase();try{window.localStorage.setItem("motionflow.glassTint",normaliseHex(value));}catch(e){}}
    if(id==="glassTintPicker"&&$("glassTintHex")){$("glassTintHex").value=value.toUpperCase();try{window.localStorage.setItem("motionflow.glassTint",normaliseHex(value));}catch(e){}}
  });
  document.addEventListener("change",function(e){if(e.target&&e.target.name==="glassMaterial"){try{window.localStorage.setItem("motionflow.glassMaterial",e.target.value);}catch(e2){}syncGlassMaterialUI();}});
  document.addEventListener("click",function(e){var f=e.target.closest?e.target.closest("[data-filter]"):null;if(f){Array.prototype.forEach.call(document.querySelectorAll(".filter-chips .preset-chip"),function(b){b.classList.toggle("active",b===f);});filterCatalog();}});
  document.addEventListener("mouseover",function(e){var node=e.target.closest?e.target.closest("[data-action]"):null;if(node&&!node.getAttribute("title")){var act=node.getAttribute("data-action");if(actionTips[act])node.setAttribute("title",actionTips[act]);}});
  document.addEventListener("focusin",function(e){var node=e.target.closest?e.target.closest("[data-action]"):null;if(node&&!node.getAttribute("title")){var act=node.getAttribute("data-action");if(actionTips[act])node.setAttribute("title",actionTips[act]);}});
  initAppearance();
  setCurrentFill(currentFillHex(),false);
  openPage("home"); refreshContext();
  window.setInterval(function(){if(bridgeAvailable())refreshContext();},5000);
})();
