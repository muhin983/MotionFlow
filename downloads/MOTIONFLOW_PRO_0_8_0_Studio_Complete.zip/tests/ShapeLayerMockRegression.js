const fs=require('fs'),vm=require('vm');
const src=fs.readFileSync(__dirname+'/../MOTIONFLOW_PRO_CEP/host/MotionFlowHost.jsx','utf8');
function val(v,matchName){return {matchName:matchName||'',value:v,setValue(x){this.value=Array.isArray(x)?x.slice():x;}};}
function makeShapeLayer(){
  const layer={name:'',selected:false,threeDLayer:false,parent:null}; let generation=0; const rootItems=[];
  function item(kind){
    const obj={matchName:kind,name:kind,props:{}};
    if(kind==='ADBE Vector Group') obj.contents=[];
    if(kind==='ADBE Vector Shape - Rect') {obj.props['ADBE Vector Rect Size']=val([0,0],'ADBE Vector Rect Size');obj.props['ADBE Vector Rect Roundness']=val(0,'ADBE Vector Rect Roundness');}
    if(kind==='ADBE Vector Shape - Ellipse') obj.props['ADBE Vector Ellipse Size']=val([0,0],'ADBE Vector Ellipse Size');
    if(kind==='ADBE Vector Graphic - Fill'){obj.props['ADBE Vector Fill Color']=val([0,0,0],'ADBE Vector Fill Color');obj.props['ADBE Vector Fill Opacity']=val(100,'ADBE Vector Fill Opacity');}
    return obj;
  }
  function group(items, expected, owner){
    return {get numProperties(){if(expected!==generation)throw new Error('Stale PropertyGroup');return items.length;},
      addProperty(kind){if(expected!==generation)throw new Error('Stale PropertyGroup');items.push(item(kind));generation++;return items[items.length-1];},
      property(key){if(expected!==generation)throw new Error('Stale PropertyGroup');
        if(owner && key==='ADBE Vectors Group')return group(owner.contents,generation,owner);
        let ob=typeof key==='number'?items[key-1]:items.find(x=>x.matchName===key);if(!ob)return null;
        if(ob.matchName==='ADBE Vector Group')return vectorGroup(ob,generation);
        return propertyObject(ob,generation);
      }};
  }
  function vectorGroup(obj, expected){
    return {matchName:obj.matchName,get name(){if(expected!==generation)throw new Error('Stale PropertyGroup');return obj.name;},set name(v){if(expected!==generation)throw new Error('Stale PropertyGroup');obj.name=v;},get numProperties(){if(expected!==generation)throw new Error('Stale PropertyGroup');return obj.contents.length;},
      property(key){if(expected!==generation)throw new Error('Stale PropertyGroup');if(key==='ADBE Vectors Group')return group(obj.contents,generation,obj);let child=typeof key==='number'?obj.contents[key-1]:null;return child?propertyObject(child,generation):null;}};
  }
  function propertyObject(obj, expected){
    return {get name(){if(expected!==generation)throw new Error('Stale PropertyGroup');return obj.name;},set name(v){if(expected!==generation)throw new Error('Stale PropertyGroup');obj.name=v;},matchName:obj.matchName,
      propertyIndex:rootItems.indexOf(obj)+1,
      property(key){if(expected!==generation)throw new Error('Stale PropertyGroup');if(typeof key==='number'){const vals=Object.values(obj.props);return vals[key-1]||null;}return obj.props[key]||null;},
      get numProperties(){if(expected!==generation)throw new Error('Stale PropertyGroup');return obj.contents?obj.contents.length:Object.keys(obj.props).length;}};
  }
  layer.property=(key)=>{
    if(key==='ADBE Root Vectors Group')return group(rootItems,generation);
    if(key==='ADBE Transform Group')return {property(n){if(n==='ADBE Position')return pos;return null;}};
    return null;
  };
  const pos=val([960,540]);
  layer._inspect=()=>({rootItems,generation});
  return layer;
}
function CompItem(){}
function SolidSource(){this.color=[1,1,1];}
const layers=[];
const comp=new CompItem();comp.width=1920;comp.height=1080;comp.pixelAspect=1;comp.duration=10;comp.frameRate=30;comp.time=0;comp.numLayers=0;
comp.layers={addShape(){const l=makeShapeLayer();layers.unshift(l);comp.numLayers=layers.length;return l;},addSolid(rgb,name){const l={name,selected:false,source:{mainSource:new SolidSource()},property(){return null;}};l.source.mainSource.color=rgb.slice();layers.unshift(l);comp.numLayers=layers.length;return l;}};
comp.layer=i=>layers[i-1];Object.defineProperty(comp,'selectedLayers',{get(){return layers.filter(l=>l.selected);}});
const sandbox={CompItem,SolidSource,app:{project:{activeItem:comp},beginUndoGroup(){},endUndoGroup(){}},$:{global:{}}};vm.createContext(sandbox);vm.runInContext(src,sandbox);
const MF=sandbox.$.global.MOTIONFLOW_PRO;
function test(kind){const result=JSON.parse(MF.create(kind,'54A8FF'));if(!result.ok)throw new Error(result.message);const layer=layers[0];if(!layer.selected)throw new Error('New layer was not selected');const root=layer._inspect().rootItems;if(root.length!==1)throw new Error('Expected one vector group');const contents=root[0].contents;if(!contents.some(x=>x.matchName==='ADBE Vector Graphic - Fill'))throw new Error('Fill group missing');const fill=contents.find(x=>x.matchName==='ADBE Vector Graphic - Fill');const colour=fill.props['ADBE Vector Fill Color'].value;if(colour[0]<.32||colour[1]<.65||colour[2]<.95)throw new Error('HEX colour was not mapped to vector fill');console.log('PASS:',kind+' creates editable vector layer and writes HEX fill despite PropertyGroup invalidation');}
test('Rectangle');const rectangle=layers[0];test('Ellipse');
rectangle.selected=true;for(const l of layers)if(l!==rectangle)l.selected=false;const shapeColour=JSON.parse(MF.applyColorToSelection('#FF00FF'));if(!shapeColour.ok)throw new Error(shapeColour.message);const groupFill=rectangle._inspect().rootItems[0].contents.find(x=>x.matchName==='ADBE Vector Graphic - Fill').props['ADBE Vector Fill Color'].value;if(groupFill[0]!==1||groupFill[1]!==0||groupFill[2]!==1)throw new Error('Shape fill recolouring failed');console.log('PASS: Color Studio recolours editable shape fills');
const solidResult=JSON.parse(MF.create('Solid','54A8FF'));if(!solidResult.ok)throw new Error(solidResult.message);if(!layers[0].selected)throw new Error('New solid was not selected');console.log('PASS: Solid layer is created natively and selected');
const recolour=JSON.parse(MF.applyColorToSelection('#FF0000'));if(!recolour.ok)throw new Error(recolour.message);const rgb=layers[0].source.mainSource.color;if(rgb[0]!==1||rgb[1]!==0||rgb[2]!==0)throw new Error('Solid source did not receive new HEX colour');console.log('PASS: SolidSource recolouring writes the chosen HEX RGB values');
