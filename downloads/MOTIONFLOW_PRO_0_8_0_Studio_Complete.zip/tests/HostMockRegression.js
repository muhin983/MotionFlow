const fs = require('fs');
const vm = require('vm');
const src = fs.readFileSync(__dirname + '/../MOTIONFLOW_PRO_CEP/host/MotionFlowHost.jsx', 'utf8');
function property(value, extra={}) {
  const p = Object.assign({value, numKeys:0, expressionEnabled:false, expression:'', dimensionsSeparated:false, canSetExpression:true, propertyType:1,
    setValue(v){ this.value = Array.isArray(v) ? v.slice() : v; },
    setValueAtTime(t,v){ this.numKeys++; this.value = Array.isArray(v) ? v.slice() : v; },
  }, extra);
  return p;
}
function makeLayer(is3d=false) {
  const layer = {name:'Mock Layer', parent:null, _threeD:!!is3d};
  let pos = property(is3d ? [10,20,30] : [10,20]);
  let scale = property(is3d ? [100,100,100] : [100,100]);
  let rotation = property(0);
  let opacity = property(100);
  Object.defineProperty(layer,'threeDLayer',{get(){return this._threeD;},set(v){
    const old=pos.value.slice(); this._threeD=!!v;
    if(this._threeD && old.length===2) old.push(0);
    if(!this._threeD && old.length===3) old.length=2;
    pos=property(old); scale=property(this._threeD?[100,100,100]:[100,100]); rotation=property(0); opacity=property(100);
  }});
  layer.property=(match)=>match==='ADBE Transform Group'?({property:(n)=>({'ADBE Position':pos,'ADBE Scale':scale,'ADBE Rotate Z':rotation,'ADBE Rotation':rotation,'ADBE Opacity':opacity})[n]||null}):null;
  layer._props=()=>({pos,scale,rotation,opacity});
  return layer;
}
function makeComp(layer, selectedProperties=[]) {
  function CompItem() {}
  const comp = new CompItem(); comp.name='Mock Comp'; comp.width=1920; comp.height=1080; comp.frameRate=30; comp.duration=10; comp.time=1; comp.numLayers=1;
  comp.selectedLayers=[layer]; comp.selectedProperties=selectedProperties;
  const sandbox = {CompItem, PropertyType:{PROPERTY:1}, app:{project:{activeItem:comp},beginUndoGroup(){},endUndoGroup(){}}, $:{global:{}}, console};
  vm.createContext(sandbox); vm.runInContext(src,sandbox);
  return {MF:sandbox.$.global.MOTIONFLOW_PRO,comp};
}
function assert(test,msg){ if(!test) throw new Error(msg); console.log('PASS:',msg); }
// 2D -> 3D Z transform must preserve X/Y and write Z.
{
  const layer=makeLayer(false), {MF}=makeComp(layer);
  const result=JSON.parse(MF.applyTransform('120','240','360','','','',''));
  const p=layer._props().pos.value;
  assert(result.ok && layer.threeDLayer && p[0]===120 && p[1]===240 && p[2]===360,'Position Z auto-enables 3D and preserves X/Y');
}
// Existing expression must not be silently overwritten when checkbox is false, even if expression is disabled.
{
  const layer=makeLayer(false), target=property(0,{numKeys:2,expression:'wiggle(2,35)',expressionEnabled:false});
  const {MF}=makeComp(layer,[target]);
  const result=JSON.parse(MF.expression('pingpong','0','0','false','auto'));
  assert(!result.ok && target.expression==='wiggle(2,35)','Existing disabled expression is protected when Replace is off');
  const replaced=JSON.parse(MF.expression('pingpong','0','0','true','auto'));
  assert(replaced.ok && target.expression==='loopOut("pingpong")' && target.expressionEnabled,'Replace checkbox explicitly permits Loop PingPong');
}
// Loop Out with fewer than two keys must fail clearly.
{
  const layer=makeLayer(false), target=property(0,{numKeys:1,expression:'',expressionEnabled:false});
  const {MF}=makeComp(layer,[target]);
  const result=JSON.parse(MF.expression('cycle','0','0','false','auto'));
  assert(!result.ok && /at least two keyframes/i.test(result.message),'Loop Out with one keyframe returns a clear failure');
}
console.log('Mock host regression tests complete.');
