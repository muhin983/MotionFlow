MOTIONFLOW PRO 0.8.0 MOCK REGRESSION TESTS

These Node.js test harnesses mock a small part of the After Effects host and exercise defensive code paths. They are not a replacement for running the extension inside Adobe After Effects 2025.

Run from this folder with Node.js 18+:
  node HostMockRegression.js
  node ShapeLayerMockRegression.js

HostMockRegression checks 2D-to-3D Position Z, expression replacement safety and the 2-key Loop Out requirement.
ShapeLayerMockRegression checks Solid/Rectangle/Ellipse creation, vector-group reference re-acquisition and colour application to native SolidSource / editable shape fills.
